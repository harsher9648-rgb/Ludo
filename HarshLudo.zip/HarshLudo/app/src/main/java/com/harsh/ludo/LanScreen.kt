package com.harsh.ludo

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun StatusDot() {
    val (dot, label) = when (Lan.status) { 2 -> "🟢" to R.string.connected; 1 -> "🟡" to R.string.connecting; else -> "🔴" to R.string.disconnected }
    Text("$dot ${stringResource(label)}", color = fg(), fontSize = 15.sp)
}

@Composable
fun LanScreen() {
    var codeIn by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).padding(top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.offline_lan), color = fg(), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        if (Lan.msg.isNotEmpty()) Text(Lan.msg, color = fg().copy(0.85f), fontSize = 16.sp)
        when (Lan.mode) {
            0 -> {
                GlassButton(stringResource(R.string.create_game), Modifier.fillMaxWidth()) { Lan.startHost() }
                GlassButton(stringResource(R.string.join_game), Modifier.fillMaxWidth()) { Lan.openJoin() }
            }
            1 -> {
                Glass(Modifier.fillMaxWidth()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.room_code), color = fg().copy(0.8f), fontSize = 15.sp)
                        Text(Lan.code, color = fg(), fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                        Text(Lan.hostIp, color = fg().copy(0.7f), fontSize = 14.sp)
                        StatusDot()
                    }
                }
                Glass(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.connected_players), color = fg().copy(0.8f), fontSize = 15.sp)
                        Lan.roster.forEachIndexed { i, n ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${i + 1}. $n", color = pColors[listOf(0, 1, 2, 3)[i]], fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (i > 0) GlassButton(stringResource(R.string.kick), Modifier.width(110.dp)) { Lan.kick(n) }
                            }
                        }
                    }
                }
                GlassButton(stringResource(R.string.start_game), Modifier.fillMaxWidth(), enabled = Lan.roster.size >= 2) { Lan.startGame() }
                if (Lan.roster.size < 2) Text(stringResource(R.string.need_two), color = fg().copy(0.7f), fontSize = 14.sp)
            }
            else -> {
                StatusDot()
                if (Lan.joined) {
                    Glass(Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(R.string.connected_players), color = fg().copy(0.8f), fontSize = 15.sp)
                            Lan.roster.forEachIndexed { i, n -> Text("${i + 1}. $n", color = pColors[i % 4], fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                } else {
                    Text(stringResource(R.string.rooms_found), color = fg().copy(0.8f), fontSize = 15.sp)
                    Lan.rooms.forEach { r -> GlassButton(r.name, Modifier.fillMaxWidth()) { Lan.startJoin(r.ip) } }
                    OutlinedTextField(codeIn, { codeIn = it.filter { c -> c.isDigit() }.take(6) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text(stringResource(R.string.enter_code)) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = fg(), unfocusedTextColor = fg(),
                            focusedLabelColor = fg(), unfocusedLabelColor = fg().copy(0.7f)))
                    GlassButton(stringResource(R.string.join), Modifier.fillMaxWidth(), enabled = codeIn.length == 6) {
                        Lan.ipFromCode(codeIn)?.let { Lan.startJoin(it) }
                    }
                }
            }
        }
    }
}

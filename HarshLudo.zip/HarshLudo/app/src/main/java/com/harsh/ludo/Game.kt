package com.harsh.ludo

import androidx.compose.runtime.*

/** Board geometry: 52-cell ring on a 15x15 grid + 5-cell home column per player. */
object Board {
    private fun seg(x: Int, y: Int, dx: Int, dy: Int, n: Int) = (0 until n).map { (x + dx * it) to (y + dy * it) }
    val ring: List<Pair<Int, Int>> =
        seg(1, 6, 1, 0, 5) + seg(6, 5, 0, -1, 6) + seg(7, 0, 1, 0, 2) + seg(8, 1, 0, 1, 5) +
        seg(9, 6, 1, 0, 6) + seg(14, 7, 0, 1, 2) + seg(13, 8, -1, 0, 5) + seg(8, 9, 0, 1, 6) +
        seg(7, 14, -1, 0, 2) + seg(6, 13, 0, -1, 5) + seg(5, 8, -1, 0, 6) + seg(0, 7, 0, -1, 2)
    /** Ring index where each player (Red, Green, Yellow, Blue) enters. */
    val start = listOf(0, 13, 26, 39)
    val safeIdx: Set<Int> = (start + start.map { (it + 8) % 52 }).toSet()
    val safeCells: Set<Pair<Int, Int>> = safeIdx.map { ring[it] }.toSet()
    private val home = listOf(intArrayOf(0, 7, 1, 0), intArrayOf(7, 0, 0, 1), intArrayOf(14, 7, -1, 0), intArrayOf(7, 14, 0, -1))
    fun yardX(p: Int) = if (p == 1 || p == 2) 9 else 0
    fun yardY(p: Int) = if (p >= 2) 9 else 0
    /** Progress 0..50 = ring, 51..55 = home column, 56 = home. */
    fun cell(p: Int, k: Int): Pair<Int, Int> =
        if (k <= 50) ring[(start[p] + k) % 52]
        else { val h = home[p]; val n = k - 50; (h[0] + h[2] * n) to (h[1] + h[3] * n) }
}

/**
 * Authoritative Ludo rules. Pure logic: the LAN host will own one instance
 * and clients will only send "roll"/"move(i)" requests.
 */
class Game(val players: List<Int>, val bots: Set<Int>) {
    val prog = Array(4) { IntArray(4) { -1 } } // -1 = in yard
    var turn by mutableIntStateOf(players[0])
    var dice by mutableIntStateOf(0)
    var rolled by mutableStateOf(false)
    var winner by mutableIntStateOf(-1)
    var version by mutableIntStateOf(0)

    fun movable(): List<Int> = if (!rolled || winner >= 0) emptyList() else (0..3).filter {
        val p = prog[turn][it]; if (p < 0) dice == 6 else p + dice <= 56
    }

    fun roll() {
        if (rolled || winner >= 0) return
        dice = (1..6).random(); rolled = true; version++
        if (movable().isEmpty()) endTurn(false)
    }

    private fun target(i: Int) = if (prog[turn][i] < 0) 0 else prog[turn][i] + dice

    private fun captures(i: Int): List<Pair<Int, Int>> {
        val t = target(i)
        if (t > 50) return emptyList()
        val cell = Board.ring[(Board.start[turn] + t) % 52]
        if (cell in Board.safeCells) return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        for (q in players) if (q != turn) for (j in 0..3) {
            val p = prog[q][j]
            if (p in 0..50 && Board.cell(q, p) == cell) out.add(q to j)
        }
        return out
    }

    fun move(i: Int) {
        if (i !in movable()) return
        val caps = captures(i)
        prog[turn][i] = target(i)
        caps.forEach { prog[it.first][it.second] = -1 }
        if (prog[turn].all { it == 56 }) { winner = turn; version++; return }
        endTurn(dice == 6 || caps.isNotEmpty() || prog[turn][i] == 56)
    }

    private fun endTurn(extra: Boolean) {
        rolled = false
        if (!extra) turn = players[(players.indexOf(turn) + 1) % players.size]
        version++
    }

    fun botStep() {
        if (!rolled) { roll(); return }
        val best = movable().maxByOrNull { if (captures(it).isNotEmpty()) 100 else if (prog[turn][it] < 0) 50 else prog[turn][it] }
        if (best != null) move(best)
    }

    /** Token center in grid units. */
    fun pos(p: Int, i: Int): Pair<Float, Float> {
        val k = prog[p][i]
        return if (k < 0) (Board.yardX(p) + 2f + (i % 2) * 2f) to (Board.yardY(p) + 2f + (i / 2) * 2f)
        else Board.cell(p, k).let { (it.first + 0.5f) to (it.second + 0.5f) }
    }

    fun tap(gx: Float, gy: Float) {
        if (turn in bots) return
        val hit = movable().minByOrNull { val (x, y) = pos(turn, it); (x - gx) * (x - gx) + (y - gy) * (y - gy) } ?: return
        val (x, y) = pos(turn, hit)
        if ((x - gx) * (x - gx) + (y - gy) * (y - gy) < 0.7f) move(hit)
    }
}

package com.harsh.ludo

import androidx.compose.runtime.*

/** Board geometry: 52-cell ring on a 15x15 grid + 5-cell home column per player. */
object Board {
    private fun seg(x: Int, y: Int, dx: Int, dy: Int, n: Int) = (0 until n).map { (x + dx * it) to (y + dy * it) }
    private fun rot(p: Pair<Int, Int>) = p.second to (14 - p.first)   // rotate layout: red bottom-left, clockwise
    val ring: List<Pair<Int, Int>> = (
        seg(1, 6, 1, 0, 5) + seg(6, 5, 0, -1, 6) + seg(7, 0, 1, 0, 2) + seg(8, 1, 0, 1, 5) +
        seg(9, 6, 1, 0, 6) + seg(14, 7, 0, 1, 2) + seg(13, 8, -1, 0, 5) + seg(8, 9, 0, 1, 6) +
        seg(7, 14, -1, 0, 2) + seg(6, 13, 0, -1, 5) + seg(5, 8, -1, 0, 6) + seg(0, 7, 0, -1, 2)).map { rot(it) }
    /** Ring index where each player (Red, Green, Yellow, Blue) enters. */
    val start = listOf(0, 13, 26, 39)
    val safeIdx: Set<Int> = (start + start.map { (it + 8) % 52 }).toSet()
    val safeCells: Set<Pair<Int, Int>> = safeIdx.map { ring[it] }.toSet()
    private val home = listOf(intArrayOf(0, 7, 1, 0), intArrayOf(7, 0, 0, 1), intArrayOf(14, 7, -1, 0), intArrayOf(7, 14, 0, -1))
    fun yardX(p: Int) = if (p >= 2) 9 else 0
    fun yardY(p: Int) = if (p == 1 || p == 2) 0 else 9
    /** Progress 0..50 = ring, 51..55 = home column, 56 = home. */
    fun cell(p: Int, k: Int): Pair<Int, Int> =
        if (k <= 50) ring[(start[p] + k) % 52]
        else { val h = home[p]; val n = k - 50; rot((h[0] + h[2] * n) to (h[1] + h[3] * n)) }
}

/**
 * Authoritative Ludo rules. On LAN only the HOST runs the rules; clients (send != null)
 * forward "ROLL"/"MOVE|i" to the host and just display the state they receive.
 */
class Game(val players: List<Int>, val bots: Set<Int>) {
    val prog = Array(4) { IntArray(4) { -1 } } // -1 = in yard
    var turn by mutableIntStateOf(players[0])
    var dice by mutableIntStateOf(0)
    var rolled by mutableStateOf(false)
    var winner by mutableIntStateOf(-1)
    var version by mutableIntStateOf(0)
    var rollBy by mutableIntStateOf(0)    // who rolled last (their corner slot shows the dice)
    var rollSeq by mutableIntStateOf(0)   // increments on every roll; drives dice animation on all phones
    var onEvent: (String) -> Unit = {}
    var onChange: (() -> Unit)? = null
    var send: ((String) -> Unit)? = null
    var mySeat = -1                       // -1 = local game (all humans share the phone)
    var names: Map<Int, String> = emptyMap()

    fun canAct() = winner < 0 && (if (mySeat >= 0) turn == mySeat else turn !in bots)
    private fun bump() { version++; onChange?.invoke() }

    fun movable(): List<Int> = if (!rolled || winner >= 0) emptyList() else (0..3).filter {
        val p = prog[turn][it]; if (p < 0) dice == 6 else p + dice <= 56
    }

    fun roll() {
        if (rolled || winner >= 0) return
        send?.let { it("ROLL"); return }
        dice = (1..6).random(); rolled = true; rollBy = turn; rollSeq++; bump()
        onEvent(if (dice == 6) "six" else "result")
        if (movable().isEmpty()) endTurn(false)
    }

    private fun target(i: Int) = if (prog[turn][i] < 0) 0 else prog[turn][i] + dice

    private fun captures(i: Int): List<Pair<Int, Int>> {
        val t = target(i)
        if (t > 50) return emptyList()
        val cell = Board.ring[(Board.start[turn] + t) % 52]
        if (cell in Board.safeCells) return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        for (q in players) if (q != turn) for (j in 0..3) {
            val p = prog[q][j]
            if (p in 0..50 && Board.cell(q, p) == cell) out.add(q to j)
        }
        return out
    }

    fun move(i: Int) {
        if (i !in movable()) return
        send?.let { it("MOVE|$i"); return }
        val caps = captures(i)
        prog[turn][i] = target(i)
        caps.forEach { prog[it.first][it.second] = -1 }
        if (prog[turn].all { it == 56 }) { winner = turn; bump(); onEvent("win"); return }
        onEvent(if (caps.isNotEmpty()) "capture" else if (prog[turn][i] == 56) "home" else "move")
        endTurn(dice == 6 || caps.isNotEmpty() || prog[turn][i] == 56)
    }

    private fun endTurn(extra: Boolean) {
        rolled = false
        if (!extra) turn = players[(players.indexOf(turn) + 1) % players.size]
        bump()
    }

    /** Host side: a client asked for an action. Only the player whose turn it is may act. */
    fun request(seat: Int, msg: String) {
        if (seat != turn) return
        if (msg == "ROLL") roll() else if (msg.startsWith("MOVE|")) msg.substring(5).toIntOrNull()?.let { move(it) }
    }

    fun encode() = "S|$turn|$dice|${if (rolled) 1 else 0}|$winner|" + prog.joinToString(",") { it.joinToString(",") } + "|$rollSeq|$rollBy"

    /** Client side: overwrite local state with the host's authoritative state. */
    fun applyState(s: String) {
        val t = s.split("|"); if (t.size < 6) return
        turn = t[1].toInt(); dice = t[2].toInt(); rolled = t[3] == "1"; winner = t[4].toInt()
        val v = t[5].split(",").map { it.toInt() }
        for (p in 0..3) for (i in 0..3) prog[p][i] = v[p * 4 + i]
        if (t.size > 6) rollSeq = t[6].toInt()
        if (t.size > 7) rollBy = t[7].toInt()
        version++
    }

    fun botStep() {
        if (!rolled) { roll(); return }
        val best = movable().maxByOrNull { if (captures(it).isNotEmpty()) 100 else if (prog[turn][it] < 0) 50 else prog[turn][it] }
        if (best != null) move(best)
    }

    /** Token center in grid units. */
    fun pos(p: Int, i: Int): Pair<Float, Float> {
        val k = prog[p][i]
        return if (k < 0) (Board.yardX(p) + 2f + (i % 2) * 2f) to (Board.yardY(p) + 2f + (i / 2) * 2f)
        else Board.cell(p, k).let { (it.first + 0.5f) to (it.second + 0.5f) }
    }

    fun tap(gx: Float, gy: Float) {
        if (!canAct()) return
        val hit = movable().minByOrNull { val (x, y) = pos(turn, it); (x - gx) * (x - gx) + (y - gy) * (y - gy) } ?: return
        val (x, y) = pos(turn, hit)
        if ((x - gx) * (x - gx) + (y - gy) * (y - gy) < 0.9f) move(hit)
    }
}

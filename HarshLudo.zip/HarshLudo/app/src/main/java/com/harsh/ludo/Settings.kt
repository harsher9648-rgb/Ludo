package com.harsh.ludo

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = fg(), fontSize = 17.sp, modifier = Modifier.weight(1f))
        Switch(v, onChange)
    }
}

@Composable
fun SliderRow(label: String, v: Float, onChange: (Float) -> Unit) {
    Column { Text(label, color = fg(), fontSize = 17.sp); Slider(v, onChange) }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).padding(top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.settings), color = fg(), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Glass(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SwitchRow(stringResource(R.string.sfx), Prefs.sfxOn) { Prefs.sfxOn = it; Prefs.save() }
                SliderRow(stringResource(R.string.sfx_volume), Prefs.sfxVol) { Prefs.sfxVol = it; Prefs.save() }
                SwitchRow(stringResource(R.string.music), Prefs.musicOn) { Prefs.musicOn = it; Prefs.save(); Sfx.applyMusic() }
                SliderRow(stringResource(R.string.music_volume), Prefs.musicVol) { Prefs.musicVol = it; Prefs.save(); Sfx.applyMusic() }
                SwitchRow(stringResource(R.string.vibration), Prefs.vibrate) { Prefs.vibrate = it; Prefs.save() }
                SwitchRow(stringResource(R.string.dark_theme), Prefs.dark) { Prefs.dark = it; Prefs.save() }
                OutlinedTextField(Prefs.name, { Prefs.name = it.take(12); Prefs.save() }, singleLine = true,
                    label = { Text(stringResource(R.string.player_name)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = fg(), unfocusedTextColor = fg(),
                        focusedLabelColor = fg(), unfocusedLabelColor = fg().copy(0.7f)))
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("👑", fontSize = 34.sp)
                Text(stringResource(R.string.about), color = Gold, fontSize = 15.sp)
                Text("HARSH LUDO", color = fg(), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(stringResource(R.string.about_by), color = fg(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.about_desc), color = fg().copy(0.8f), fontSize = 15.sp)
                Text(stringResource(R.string.version), color = fg().copy(0.6f), fontSize = 14.sp)
            }
        }
    }
}


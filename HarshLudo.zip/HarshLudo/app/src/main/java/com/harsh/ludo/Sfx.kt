package com.harsh.ludo

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import androidx.compose.runtime.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Settings saved locally (SharedPreferences). Compose state so UI updates instantly. */
object Prefs {
    private var sp: SharedPreferences? = null
    var sfxOn by mutableStateOf(true)
    var musicOn by mutableStateOf(true)
    var sfxVol by mutableFloatStateOf(0.8f)
    var musicVol by mutableFloatStateOf(0.4f)
    var vibrate by mutableStateOf(true)
    var dark by mutableStateOf(true)
    var name by mutableStateOf("Player")

    fun load(c: Context) {
        val s = c.getSharedPreferences("harsh", Context.MODE_PRIVATE); sp = s
        sfxOn = s.getBoolean("sfxOn", true); musicOn = s.getBoolean("musicOn", true)
        sfxVol = s.getFloat("sfxVol", 0.8f); musicVol = s.getFloat("musicVol", 0.4f)
        vibrate = s.getBoolean("vibrate", true); dark = s.getBoolean("dark", true)
        name = s.getString("name", "Player") ?: "Player"
    }

    fun save() {
        sp?.edit()?.putBoolean("sfxOn", sfxOn)?.putBoolean("musicOn", musicOn)?.putFloat("sfxVol", sfxVol)
            ?.putFloat("musicVol", musicVol)?.putBoolean("vibrate", vibrate)?.putBoolean("dark", dark)
            ?.putString("name", name)?.apply()
    }
}

/** All sounds are synthesized in code at first launch: no copyrighted assets, tiny APK. */
object Sfx {
    private const val SR = 22050
    private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<String, Int>()
    private var music: MediaPlayer? = null
    private var vib: Vibrator? = null
    private var ctx: Context? = null

    private fun tone(f0: Double, f1: Double, d: Double, amp: Double = 0.5, decay: Double = 6.0): ShortArray {
        val n = (SR * d).toInt(); var ph = 0.0
        return ShortArray(n) { i ->
            val t = i.toDouble() / n
            ph += 2 * PI * (f0 + (f1 - f0) * t) / SR
            (sin(ph) * amp * exp(-decay * t) * min(1.0, i / 200.0) * 32767).toInt().toShort()
        }
    }

    private fun noise(d: Double, amp: Double = 0.4): ShortArray {
        val n = (SR * d).toInt(); val r = java.util.Random(7)
        return ShortArray(n) { i -> ((r.nextDouble() * 2 - 1) * amp * (1 - i.toDouble() / n) * 32767).toInt().toShort() }
    }

    private fun seq(vararg p: ShortArray): ShortArray = p.reduce { a, b -> a + b }
    private fun gap(d: Double) = ShortArray((SR * d).toInt())

    private fun wav(s: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + s.size * 2).put("WAVEfmt ".toByteArray()).putInt(16)
            .putShort(1.toShort()).putShort(1.toShort()).putInt(SR).putInt(SR * 2).putShort(2.toShort()).putShort(16.toShort())
        bb.put("data".toByteArray()).putInt(s.size * 2)
        s.forEach { bb.putShort(it) }
        return bb.array()
    }

    fun init(c: Context) {
        ctx = c.applicationContext
        vib = c.getSystemService(Vibrator::class.java)
        val p = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
        pool = p
        Thread {
            val defs = mapOf(
                "click" to tone(880.0, 880.0, 0.05),
                "shake" to seq(noise(0.04), gap(0.03), noise(0.04), gap(0.03), noise(0.04)),
                "result" to seq(tone(660.0, 660.0, 0.08), tone(880.0, 880.0, 0.12)),
                "move" to tone(520.0, 560.0, 0.06, 0.4),
                "capture" to tone(420.0, 120.0, 0.28, 0.6, 4.0),
                "six" to seq(tone(523.0, 523.0, 0.08), tone(659.0, 659.0, 0.08), tone(784.0, 784.0, 0.08), tone(1047.0, 1047.0, 0.2)),
                "home" to seq(tone(659.0, 659.0, 0.1), tone(880.0, 880.0, 0.1), tone(1175.0, 1175.0, 0.25)),
                "turn" to tone(700.0, 760.0, 0.07, 0.35),
                "win" to seq(tone(523.0, 523.0, 0.12), tone(659.0, 659.0, 0.12), tone(784.0, 784.0, 0.12),
                    tone(1047.0, 1047.0, 0.15), tone(1319.0, 1319.0, 0.15), tone(1568.0, 1568.0, 0.5, 0.5, 3.0))
            )
            for ((k, v) in defs) {
                val f = File(c.cacheDir, "$k.wav"); f.writeBytes(wav(v))
                ids[k] = p.load(f.path, 1)
            }
            // Soft ambient loop: pentatonic pad notes, 2s each (16s loop).
            val hz = doubleArrayOf(261.6, 293.7, 329.6, 392.0, 440.0, 523.3)
            val notes = intArrayOf(0, 2, 4, 2, 3, 1, 4, 5).map { tone(hz[it], hz[it], 2.0, 0.3, 4.0) }
            File(c.cacheDir, "music.wav").writeBytes(wav(notes.reduce { a, b -> a + b }))
            Handler(Looper.getMainLooper()).post { applyMusic() }
        }.start()
    }

    @Suppress("DEPRECATION")
    fun play(name: String) {
        if (Prefs.sfxOn) ids[name]?.let { pool?.play(it, Prefs.sfxVol, Prefs.sfxVol, 1, 0, 1f) }
        if (Prefs.vibrate && (name == "capture" || name == "six" || name == "home" || name == "win")) vib?.vibrate(35)
    }

    fun applyMusic() {
        val f = File(ctx?.cacheDir, "music.wav")
        if (!f.exists()) return
        if (Prefs.musicOn) {
            if (music == null) music = MediaPlayer().apply { setDataSource(f.path); isLooping = true; prepare() }
            music?.setVolume(Prefs.musicVol, Prefs.musicVol)
            if (music?.isPlaying == false) music?.start()
        } else music?.pause()
    }

    fun pauseMusic() { music?.pause() }
}

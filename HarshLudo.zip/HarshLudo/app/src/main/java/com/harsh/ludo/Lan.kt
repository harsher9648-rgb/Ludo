package com.harsh.ludo

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import java.io.*
import java.net.*
import java.util.Collections
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class Room(val name: String, val ip: String)

/**
 * LAN layer (no internet needed). The HOST owns the only authoritative Game.
 * Clients send "ROLL" / "MOVE|i"; the host validates the sender's seat and broadcasts
 * the full state ("S|...") after every change, so a client can never alter another player's state.
 * Line protocol over TCP 45454. Host is discovered via UDP broadcast on 45455, or via a
 * 6-digit room code = last two octets of the host IP (e.g. 192.168.43.1 -> 043001).
 */
object Lan {
    const val TCP = 45454
    const val UDP = 45455
    private val main = Handler(Looper.getMainLooper())

    var mode by mutableIntStateOf(0)        // 0 choice, 1 host lobby, 2 join
    var status by mutableIntStateOf(0)      // 0 red, 1 yellow, 2 green
    var hosting by mutableStateOf(false)
    var joined by mutableStateOf(false)
    var game by mutableStateOf<Game?>(null)
    var code by mutableStateOf("")
    var hostIp by mutableStateOf("")
    var msg by mutableStateOf("")
    val roster = mutableStateListOf<String>()
    val rooms = mutableStateListOf<Room>()

    @Volatile private var active = false
    @Volatile private var giveUp = false
    private var server: ServerSocket? = null
    private var scanSock: DatagramSocket? = null
    private var clientSock: Socket? = null
    @Volatile private var writer: PrintWriter? = null
    private val cex = Executors.newSingleThreadExecutor()
    private val peers = ArrayList<Peer>()
    private var seats: Map<String, Int> = emptyMap()
    private var seatList: List<Int> = emptyList()

    private class Peer(val name: String, val sock: Socket) {
        private val w = PrintWriter(OutputStreamWriter(sock.getOutputStream(), Charsets.UTF_8), true)
        private val ex = Executors.newSingleThreadExecutor()
        fun send(s: String) { ex.execute { try { w.println(s) } catch (_: Exception) {} } }
        fun close(last: String) {
            ex.execute { try { w.println(last); sock.close() } catch (_: Exception) {} }
            ex.shutdown()
        }
    }

    private fun clean(s: String) = s.replace(Regex("[|,:]"), "").trim().take(12).ifEmpty { "Player" }

    fun localIp(): String? {
        val all = try { Collections.list(NetworkInterface.getNetworkInterfaces()) } catch (_: Exception) { return null }
        val c = all.filter { it.isUp && !it.isLoopback }.flatMap { ni ->
            Collections.list(ni.inetAddresses).filter { it is Inet4Address && it.isSiteLocalAddress }.map { ni.name to it.hostAddress }
        }
        return (c.firstOrNull { it.first.startsWith("wlan") || it.first.startsWith("ap") || it.first.startsWith("swlan") } ?: c.firstOrNull())?.second
    }

    fun ipFromCode(c: String): String? {
        if (c.length != 6) return null
        val mine = localIp()?.split(".") ?: return null
        val a = c.substring(0, 3).toIntOrNull() ?: return null
        val b = c.substring(3).toIntOrNull() ?: return null
        return "${mine[0]}.${mine[1]}.$a.$b"
    }

    // ---------------- HOST ----------------
    fun startHost() {
        stop(); active = true; hosting = true; mode = 1; status = 2
        val ip = localIp()
        if (ip == null) { msg = "No Wi-Fi / hotspot found"; status = 0; return }
        hostIp = ip
        val p = ip.split(".")
        code = "%03d%03d".format(p[2].toInt(), p[3].toInt())
        roster.add(clean(Prefs.name))
        thread(isDaemon = true) {
            try {
                val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(TCP)) }
                server = ss
                while (active) { val s = ss.accept(); thread(isDaemon = true) { handle(s) } }
            } catch (_: Exception) {}
        }
        thread(isDaemon = true) { // discovery beacon
            try {
                val d = DatagramSocket().apply { broadcast = true }
                while (active && hosting) {
                    val m = "HL|$code|${clean(Prefs.name)}|$ip".toByteArray()
                    for (a in listOf("255.255.255.255", ip.substringBeforeLast(".") + ".255"))
                        try { d.send(DatagramPacket(m, m.size, InetAddress.getByName(a), UDP)) } catch (_: Exception) {}
                    Thread.sleep(1000)
                }
                d.close()
            } catch (_: Exception) {}
        }
    }

    private fun handle(s: Socket) {
        var peer: Peer? = null
        try {
            val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            val first = r.readLine() ?: return
            if (!first.startsWith("JOIN|")) { s.close(); return }
            var name = clean(first.substring(5))
            val running = game != null
            val p = synchronized(peers) {
                if (running) {
                    if (name !in seats) { PrintWriter(s.getOutputStream(), true).println("FULL"); s.close(); return }
                    peers.firstOrNull { it.name == name }?.let { peers.remove(it); it.close("KICK") } // reconnect replaces stale peer
                } else {
                    if (peers.size >= 3) { PrintWriter(s.getOutputStream(), true).println("FULL"); s.close(); return }
                    while (name == clean(Prefs.name) || peers.any { it.name == name }) name += "2"
                }
                Peer(name, s).also { peers.add(it) }
            }
            peer = p
            if (running) main.post { game?.let { g -> p.send(startMsg(name)); p.send(g.encode()); msg = "$name reconnected" } }
            else postRoster()
            while (true) {
                val line = r.readLine() ?: break
                if (line == "ROLL" || line.startsWith("MOVE|")) main.post { seats[name]?.let { game?.request(it, line) } }
            }
        } catch (_: Exception) {
        } finally {
            peer?.let { p ->
                synchronized(peers) { peers.remove(p) }
                if (game == null) postRoster() else main.post { msg = "${p.name} disconnected"; Sfx.play("capture") }
            }
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun postRoster() = main.post {
        roster.clear(); roster.add(clean(Prefs.name))
        synchronized(peers) { roster.addAll(peers.map { it.name }) }
        broadcast("R|" + roster.joinToString(","))
    }

    private fun broadcast(s: String) = synchronized(peers) { peers.forEach { it.send(s) } }

    private fun startMsg(name: String) =
        "START|${seatList.joinToString(",")}|${seats[name]}|" + seats.entries.joinToString(",") { "${it.value}:${it.key}" }

    fun startGame() {
        val names = ArrayList<String>(); names.add(clean(Prefs.name))
        synchronized(peers) { names.addAll(peers.map { it.name }) }
        if (names.size < 2) return
        seatList = when (names.size) { 2 -> listOf(0, 2); 3 -> listOf(0, 1, 2); else -> listOf(0, 1, 2, 3) }
        seats = names.indices.associate { names[it] to seatList[it] }
        val g = Game(seatList, emptySet())
        g.mySeat = 0
        g.names = seats.entries.associate { it.value to it.key }
        g.onEvent = { e -> Sfx.play(e); broadcast("E|$e") }
        g.onChange = { broadcast(g.encode()) }
        game = g; msg = ""
        synchronized(peers) { peers.forEach { it.send(startMsg(it.name)); it.send(g.encode()) } }
        Sfx.play("click")
    }

    fun kick(name: String) { synchronized(peers) { peers.firstOrNull { it.name == name } }?.close("KICK") }

    /** Host: back to lobby (allows Restart). Client: leave the room. */
    fun exitGame() { if (hosting) { game = null; broadcast("END") } else stop() }

    // ---------------- CLIENT ----------------
    fun openJoin() { stop(); mode = 2; startScan() }

    fun startScan() {
        if (scanSock != null) return
        thread(isDaemon = true) {
            try {
                val d = DatagramSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(UDP)) }
                scanSock = d
                val buf = ByteArray(256)
                while (!d.isClosed) {
                    val pk = DatagramPacket(buf, buf.size); d.receive(pk)
                    val t = String(pk.data, 0, pk.length).split("|")
                    if (t.size >= 4 && t[0] == "HL") main.post { if (rooms.none { it.ip == t[3] }) rooms.add(Room("${t[2]} (${t[1]})", t[3])) }
                }
            } catch (_: Exception) {}
        }
    }

    fun stopScan() { try { scanSock?.close() } catch (_: Exception) {}; scanSock = null }

    fun startJoin(ip: String) {
        try { clientSock?.close() } catch (_: Exception) {}
        active = true; giveUp = false; joined = false; status = 1; msg = ""
        thread(isDaemon = true) {
            var fails = 0
            while (active && !giveUp) {
                try {
                    val s = Socket(); s.connect(InetSocketAddress(ip, TCP), 3000); s.tcpNoDelay = true
                    clientSock = s
                    val w = PrintWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8), true)
                    w.println("JOIN|" + clean(Prefs.name)); writer = w; fails = 0
                    main.post { status = 2; joined = true; mode = 2 }
                    val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                    while (true) { val line = r.readLine() ?: break; main.post { onClientLine(line) } }
                } catch (_: Exception) { fails++ }
                writer = null
                if (!active || giveUp) break
                if (game == null && fails >= 2) { main.post { msg = "Could not connect"; status = 0; joined = false }; break }
                if (fails >= 30) { main.post { msg = "Host not reachable"; status = 0 }; break }
                main.post { status = 0 } // auto-reconnect every 2s, host resends full state on rejoin
                try { Thread.sleep(2000) } catch (_: Exception) {}
                main.post { if (active) status = 1 }
            }
        }
    }

    private fun sendToHost(line: String) { cex.execute { try { writer?.println(line) } catch (_: Exception) {} } }

    private fun onClientLine(line: String) {
        try {
            when {
                line.startsWith("R|") -> { roster.clear(); roster.addAll(line.substring(2).split(",").filter { it.isNotEmpty() }) }
                line.startsWith("START|") -> {
                    val p = line.split("|")
                    val g = Game(p[1].split(",").map { it.toInt() }, emptySet())
                    g.mySeat = p[2].toInt()
                    g.names = p[3].split(",").associate { val kv = it.split(":"); kv[0].toInt() to kv[1] }
                    g.send = { l -> sendToHost(l) }
                    game = g
                }
                line.startsWith("S|") -> game?.applyState(line)
                line.startsWith("E|") -> Sfx.play(line.substring(2))
                line == "END" -> game = null
                line == "KICK" || line == "FULL" || line == "HOSTLEFT" -> {
                    giveUp = true; msg = if (line == "FULL") "Room full or game running" else if (line == "KICK") "Removed by host" else "Host left"
                    status = 0; joined = false; game = null
                }
            }
        } catch (_: Exception) {}
    }

    fun stop() {
        active = false; giveUp = true; hosting = false; joined = false; game = null; status = 0; mode = 0
        stopScan()
        try { server?.close() } catch (_: Exception) {}; server = null
        try { clientSock?.close() } catch (_: Exception) {}
        synchronized(peers) { peers.forEach { it.close("HOSTLEFT") }; peers.clear() }
        roster.clear(); rooms.clear(); msg = ""
    }
}

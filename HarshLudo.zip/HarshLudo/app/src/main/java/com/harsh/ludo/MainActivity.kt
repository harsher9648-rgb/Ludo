package com.harsh.ludo

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

val pColors = listOf(Color(0xFFFF4D5E), Color(0xFF2ECC71), Color(0xFFFFC93C), Color(0xFF3D8BFF))

@Composable fun fg() = if (Prefs.dark) Color.White else Color(0xFF1B2140)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Prefs.load(this); Sfx.init(this)
        setContent { App() }
    }
    override fun onPause() { super.onPause(); Sfx.pauseMusic() }
    override fun onResume() { super.onResume(); Sfx.applyMusic() }
}

@Composable
fun App() {
    var game by remember { mutableStateOf<Game?>(null) }
    var settings by remember { mutableStateOf(false) }
    var lan by remember { mutableStateOf(false) }
    val back: () -> Unit = {
        when {
            Lan.game != null -> Lan.exitGame()
            lan -> { Lan.stop(); lan = false }
            else -> { game = null; settings = false }
        }
    }
    BackHandler(enabled = game != null || settings || lan || Lan.game != null) { back() }
    val bg = if (Prefs.dark) listOf(Color(0xFF141C3A), Color(0xFF2E1A55), Color(0xFF0B4F5C))
    else listOf(Color(0xFFDCE8FF), Color(0xFFF1DCFF), Color(0xFFD5F5F2))
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "t")
    val dark = Prefs.dark
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(bg))) {
        // Animated glass background: two drifting light blobs + slow floating particles.
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val c1 = Offset(w * (0.3f + 0.2f * sin(t)), h * (0.25f + 0.1f * cos(t)))
            val c2 = Offset(w * (0.75f + 0.15f * cos(t)), h * (0.75f + 0.1f * sin(t)))
            drawCircle(Brush.radialGradient(listOf(Color(0x556A5CFF), Color.Transparent), c1, w * 0.8f), w * 0.8f, c1)
            drawCircle(Brush.radialGradient(listOf(Color(0x4400D4C8), Color.Transparent), c2, w * 0.8f), w * 0.8f, c2)
            for (i in 0 until 12) {
                val x = w * ((i * 0.083f + 0.03f * sin(t + i)) % 1f)
                val y = h * (1f - ((t / 6.2832f + i * 0.083f) % 1f))
                drawCircle((if (dark) Color.White else Color(0xFF1B2140)).copy(0.18f), 3f + (i % 3) * 2f, Offset(x, y))
            }
        }
        val lg = Lan.game; val g = game
        when {
            lg != null -> GameScreen(lg) { Lan.exitGame() }
            g != null -> GameScreen(g) { game = null }
            settings -> SettingsScreen()
            lan -> LanScreen()
            else -> Menu(onSettings = { settings = true }, onLan = { lan = true }) { n, bot ->
                val ps = when (n) { 2 -> listOf(0, 2); 3 -> listOf(0, 1, 2); else -> listOf(0, 1, 2, 3) }
                game = Game(ps, if (bot) ps.drop(1).toSet() else emptySet()).also { it.onEvent = { e -> Sfx.play(e) } }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, pad: Dp = 16.dp, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val a = if (Prefs.dark) listOf(0.22f, 0.08f) else listOf(0.75f, 0.4f)
    Box(modifier.background(Brush.linearGradient(a.map { Color.White.copy(it) }), shape)
        .border(1.dp, fg().copy(0.3f), shape).padding(pad),
        contentAlignment = Alignment.Center, content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Glass(modifier.heightIn(min = 56.dp).clickable(enabled = enabled) { Sfx.play("click"); onClick() }) {
        Text(text, color = fg().copy(if (enabled) 1f else 0.4f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Menu(onSettings: () -> Unit, onLan: () -> Unit, onStart: (Int, Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("HARSH LUDO", color = fg(), fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
        for (bot in listOf(false, true)) {
            Text(stringResource(if (bot) R.string.vs_bot else R.string.pass_play), color = fg().copy(0.8f), fontSize = 16.sp)
            for (n in 2..4) GlassButton(stringResource(R.string.n_players, n), Modifier.fillMaxWidth()) { onStart(n, bot) }
        }
        GlassButton("🌐 " + stringResource(R.string.offline_lan), Modifier.fillMaxWidth(), onClick = onLan)
        GlassButton("⚙ " + stringResource(R.string.settings), Modifier.fillMaxWidth(), onClick = onSettings)
    }
}

@Composable
fun GameScreen(g: Game, onExit: () -> Unit) {
    var rolling by remember { mutableStateOf(false) }
    var face by remember { mutableIntStateOf(1) }
    val scope = rememberCoroutineScope()
    suspend fun spin() { rolling = true; Sfx.play("shake"); repeat(9) { face = (1..6).random(); delay(70) }; rolling = false }

    LaunchedEffect(g.turn, g.rolled, g.version) {
        if (g.turn in g.bots && g.winner < 0) { delay(600); if (!g.rolled) spin(); g.botStep() }
    }
    LaunchedEffect(g.turn) { Sfx.play("turn") }
    val names = stringArrayResource(R.array.player_names)
    val shown = if (g.winner >= 0) g.winner else g.turn
    val nm = g.names[shown] ?: names[shown]
    val mine = g.canAct()
    Column(Modifier.fillMaxSize().padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Spacer(Modifier.height(14.dp))
        Glass(Modifier, 10.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(16.dp).background(pColors[shown], CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(if (g.winner >= 0) stringResource(R.string.wins, nm) else stringResource(R.string.turn, nm),
                    color = fg(), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                if (g.mySeat >= 0) { Spacer(Modifier.width(12.dp)); StatusDot() }
            }
        }
        BoardView(g, Modifier.fillMaxWidth().aspectRatio(1f))
        Dice(if (rolling) face else g.dice, pColors[shown], mine && !rolling && !g.rolled, rolling) {
            scope.launch { spin(); g.roll() }
        }
        Text(when { g.winner >= 0 -> ""; mine && g.rolled -> stringResource(R.string.tap_token); mine -> stringResource(R.string.tap_dice); else -> "…" },
            color = fg().copy(0.8f), fontSize = 16.sp)
        GlassButton(stringResource(R.string.menu), Modifier.width(160.dp), onClick = onExit)
    }
}

/** Tap the dice to roll. Pulsing glow in the current player's color shows when it's tappable. */
@Composable
fun Dice(n: Int, color: Color, active: Boolean, rolling: Boolean, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "dice")
    val glow by inf.animateFloat(0.25f, 0.9f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "glow")
    Canvas(Modifier.size(120.dp)
        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = active) { onClick() }
        .graphicsLayer {
            rotationZ = if (rolling) n * 57f else 0f; rotationX = if (rolling) n * 30f else 0f
            cameraDistance = 14f * density
            val s = if (rolling) 1.12f else 1f; scaleX = s; scaleY = s
        }) {
        val s = size.minDimension; val d = s * 0.7f; val o = (s - d) / 2f
        val r = CornerRadius(d * 0.22f)
        if (active) drawRoundRect(color.copy(alpha = glow * 0.55f), Offset(o - 10f, o - 10f), Size(d + 20f, d + 20f), CornerRadius(d * 0.3f))
        drawRoundRect(Color.Black.copy(0.25f), Offset(o, o + 6f), Size(d, d), r)
        drawRoundRect(Brush.linearGradient(listOf(Color.White, Color(0xFFCFD8EA))), Offset(o, o), Size(d, d), r)
        drawRoundRect(color.copy(0.85f), Offset(o, o), Size(d, d), r, style = Stroke(5f))
        val pips = when (n) { 1 -> listOf(4); 2 -> listOf(0, 8); 3 -> listOf(0, 4, 8); 4 -> listOf(0, 2, 6, 8)
            5 -> listOf(0, 2, 4, 6, 8); 6 -> listOf(0, 2, 3, 5, 6, 8); else -> emptyList() }
        for (k in pips) drawCircle(Color(0xFF1B2140), d * 0.075f,
            Offset(o + d * (0.27f + 0.23f * (k % 3)), o + d * (0.27f + 0.23f * (k / 3))))
    }
}

private fun posAt(g: Game, p: Int, i: Int, k: Float): Pair<Float, Float> {
    if (k < 0f) return g.pos(p, i)
    val a = floor(k).toInt().coerceIn(0, 56); val b = (a + 1).coerceAtMost(56); val f = k - a
    val c0 = Board.cell(p, a); val c1 = Board.cell(p, b)
    return (c0.first + (c1.first - c0.first) * f + 0.5f) to (c0.second + (c1.second - c0.second) * f + 0.5f)
}

private fun DrawScope.star(cx: Float, cy: Float, r: Float, col: Color) {
    val p = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5; val rr = if (i % 2 == 0) r else r * 0.45f
        val x = cx + (cos(a) * rr).toFloat(); val y = cy + (sin(a) * rr).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close(); drawPath(p, col)
}

@Composable
fun BoardView(g: Game, modifier: Modifier) {
    val fg = fg()
    // disp = displayed progress; walks toward the real progress one cell at a time (10 cells/s).
    val disp = remember(g) { Array(4) { p -> FloatArray(4) { i -> g.prog[p][i].toFloat() } } }
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(g.version) {
        var last = 0L; var moving = true
        while (moving) withFrameNanos { t ->
            val dt = if (last == 0L) 0f else (t - last) / 1e9f
            last = t; moving = false
            for (p in 0..3) for (i in 0..3) {
                val a = g.prog[p][i].toFloat(); val d = disp[p][i]
                if (a < 0f || d < 0f || d >= a) disp[p][i] = a
                else { disp[p][i] = minOf(a, d + dt * 10f); moving = true }
            }
            frame++
        }
    }
    val pulse by rememberInfiniteTransition(label = "bp").animateFloat(0.3f, 1f, infiniteRepeatable(tween(750), RepeatMode.Reverse), label = "pp")
    Canvas(modifier.pointerInput(g) { detectTapGestures { o -> val c = size.width / 15f; g.tap(o.x / c, o.y / c) } }) {
        frame; g.version
        val c = size.width / 15f
        drawRoundRect(Brush.linearGradient(listOf(Color.White.copy(0.28f), Color.White.copy(0.10f))), cornerRadius = CornerRadius(c * 0.8f))
        drawRoundRect(fg.copy(0.4f), cornerRadius = CornerRadius(c * 0.8f), style = Stroke(3f))
        for (p in 0..3) {
            val yx = Board.yardX(p) * c; val yy = Board.yardY(p) * c
            drawRoundRect(pColors[p].copy(0.92f), Offset(yx + c * 0.1f, yy + c * 0.1f), Size(c * 5.8f, c * 5.8f), CornerRadius(c * 0.7f))
            drawRoundRect(Color.White.copy(0.88f), Offset(yx + c * 0.9f, yy + c * 0.9f), Size(c * 4.2f, c * 4.2f), CornerRadius(c * 0.6f))
            for (i in 0..3) drawCircle(pColors[p].copy(0.35f), c * 0.5f, Offset(yx + (2f + (i % 2) * 2f) * c, yy + (2f + (i / 2) * 2f) * c))
            if (p == g.turn && g.winner < 0) // animated current-player indicator
                drawRoundRect(pColors[p].copy(alpha = pulse), Offset(yx + c * 0.1f, yy + c * 0.1f), Size(c * 5.8f, c * 5.8f), CornerRadius(c * 0.7f), style = Stroke(c * 0.22f))
        }
        fun cellBox(x: Int, y: Int, col: Color) {
            val o = Offset(x * c + c * 0.05f, y * c + c * 0.05f); val s = Size(c * 0.9f, c * 0.9f)
            drawRoundRect(col, o, s, CornerRadius(c * 0.2f))
            drawRoundRect(Color.Black.copy(0.12f), o, s, CornerRadius(c * 0.2f), style = Stroke(1.5f))
        }
        Board.ring.forEachIndexed { i, cell ->
            val sp = Board.start.indexOf(i)
            cellBox(cell.first, cell.second, if (sp >= 0) pColors[sp] else Color.White.copy(0.92f))
            if (i in Board.safeIdx) star((cell.first + 0.5f) * c, (cell.second + 0.5f) * c, c * 0.3f, if (sp >= 0) Color.White else Color(0x66000000))
        }
        for (p in 0..3) for (k in 51..55) Board.cell(p, k).let { cellBox(it.first, it.second, pColors[p].copy(0.9f)) }
        fun tri(a: Offset, b: Offset, col: Color) {
            val p = Path(); p.moveTo(a.x, a.y); p.lineTo(b.x, b.y); p.lineTo(7.5f * c, 7.5f * c); p.close(); drawPath(p, col)
        }
        tri(Offset(6 * c, 6 * c), Offset(6 * c, 9 * c), pColors[0])
        tri(Offset(6 * c, 6 * c), Offset(9 * c, 6 * c), pColors[1])
        tri(Offset(9 * c, 6 * c), Offset(9 * c, 9 * c), pColors[2])
        tri(Offset(6 * c, 9 * c), Offset(9 * c, 9 * c), pColors[3])
        val mv = if (g.canAct()) g.movable() else emptyList()
        for (p in g.players) for (i in 0..3) {
            val k = disp[p][i]
            val hop = k >= 0f && k < g.prog[p][i]
            val (x, y) = posAt(g, p, i, k)
            val o = Offset(x * c, y * c)
            if (hop) {
                val (tx, ty) = posAt(g, p, i, maxOf(0f, k - 0.7f))
                drawCircle(pColors[p].copy(0.35f), c * 0.26f, Offset(tx * c, ty * c))
            }
            val r = c * 0.36f * (if (hop) 1f + 0.25f * sin((k - floor(k)) * 3.1416f) else 1f)
            drawCircle(Color.Black.copy(0.3f), r, o + Offset(0f, c * 0.06f))
            drawCircle(Brush.radialGradient(listOf(Color.White, pColors[p]), o - Offset(r * 0.3f, r * 0.3f), r * 1.5f), r, o)
            drawCircle(Color.White, r, o, style = Stroke(3f))
            if (p == g.turn && i in mv) drawCircle(Color.White, r * 1.4f, o, alpha = pulse, style = Stroke(5f))
        }
    }
}

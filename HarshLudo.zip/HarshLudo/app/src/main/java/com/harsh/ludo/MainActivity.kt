package com.harsh.ludo

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

// Royal palette: jewel-tone players + gold accents.
val pColors = listOf(Color(0xFFD62839), Color(0xFF1FA463), Color(0xFFF2B01E), Color(0xFF2B63D9))
val Gold = Color(0xFFE8C468)
val GoldL = Color(0xFFF7E29A)
val GoldD = Color(0xFFB8862B)
private val Ivory = Color(0xFFF6EFD9)

@Composable fun fg() = if (Prefs.dark) Color(0xFFF5EEDC) else Color(0xFF241A4A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Prefs.load(this); Sfx.init(this)
        setContent { App() }
    }
    override fun onPause() { super.onPause(); Sfx.pauseMusic() }
    override fun onResume() { super.onResume(); Sfx.applyMusic() }
}

@Composable
fun App() {
    var game by remember { mutableStateOf<Game?>(null) }
    var settings by remember { mutableStateOf(false) }
    var lan by remember { mutableStateOf(false) }
    val back: () -> Unit = {
        when {
            Lan.game != null -> Lan.exitGame()
            lan -> { Lan.stop(); lan = false }
            else -> { game = null; settings = false }
        }
    }
    BackHandler(enabled = game != null || settings || lan || Lan.game != null) { back() }
    val dark = Prefs.dark
    val bg = if (dark) listOf(Color(0xFF0B0F2E), Color(0xFF231046), Color(0xFF3B1236))
    else listOf(Color(0xFFFFF7E3), Color(0xFFF6E7C4), Color(0xFFEBD6A4))
    // Liquid light blobs: pre-rendered layers moved on the GPU (no per-frame redraw = no lag).
    val drift by rememberInfiniteTransition(label = "bg").animateFloat(-1f, 1f,
        infiniteRepeatable(tween(12000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "d")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(bg))) {
        Box(Modifier.size(360.dp).align(Alignment.TopStart)
            .graphicsLayer { translationX = drift * 90f; translationY = drift * 50f }
            .background(Brush.radialGradient(listOf(Gold.copy(if (dark) 0.20f else 0.40f), Color.Transparent)), CircleShape))
        Box(Modifier.size(320.dp).align(Alignment.BottomEnd)
            .graphicsLayer { translationX = -drift * 80f; translationY = -drift * 60f }
            .background(Brush.radialGradient(listOf(Color(0xFF7C4DFF).copy(if (dark) 0.28f else 0.16f), Color.Transparent)), CircleShape))
        val key = when { Lan.game != null -> 4; game != null -> 3; settings -> 1; lan -> 2; else -> 0 }
        AnimatedContent(key, transitionSpec = {
            (fadeIn(tween(280)) + scaleIn(tween(280), initialScale = 0.96f)) togetherWith fadeOut(tween(160))
        }, label = "screen") { k ->
            when (k) {
                4 -> Lan.game?.let { GameScreen(it) { Lan.exitGame() } }
                3 -> game?.let { GameScreen(it) { game = null } }
                1 -> SettingsScreen()
                2 -> LanScreen()
                else -> Menu(onSettings = { settings = true }, onLan = { lan = true }) { n, bot ->
                    val ps = when (n) { 2 -> listOf(0, 2); 3 -> listOf(0, 1, 2); else -> listOf(0, 1, 2, 3) }
                    game = Game(ps, if (bot) ps.drop(1).toSet() else emptySet()).also { it.onEvent = { e -> Sfx.play(e) } }
                }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, pad: Dp = 16.dp, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val d = Prefs.dark
    Box(modifier
        .background(Brush.verticalGradient(listOf(Color.White.copy(if (d) 0.20f else 0.80f), Color.White.copy(if (d) 0.06f else 0.45f))), shape)
        .border(1.2.dp, Brush.verticalGradient(listOf(Gold.copy(0.85f), Gold.copy(0.15f))), shape)
        .padding(pad), contentAlignment = Alignment.Center, content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.93f else 1f, spring(0.5f, Spring.StiffnessMediumLow), label = "btn")
    Glass(modifier.heightIn(min = 56.dp).graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled) { Sfx.play("click"); onClick() }) {
        Text(text, color = fg().copy(if (enabled) 1f else 0.4f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Menu(onSettings: () -> Unit, onLan: () -> Unit, onStart: (Int, Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("👑", fontSize = 44.sp)
        Text("HARSH LUDO", style = TextStyle(brush = Brush.linearGradient(listOf(GoldL, Gold, GoldD)),
            fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp))
        for (bot in listOf(false, true)) {
            Text(stringResource(if (bot) R.string.vs_bot else R.string.pass_play), color = fg().copy(0.8f), fontSize = 16.sp)
            for (n in 2..4) GlassButton(stringResource(R.string.n_players, n), Modifier.fillMaxWidth()) { onStart(n, bot) }
        }
        GlassButton("🌐 " + stringResource(R.string.offline_lan), Modifier.fillMaxWidth(), onClick = onLan)
        GlassButton("⚙ " + stringResource(R.string.settings), Modifier.fillMaxWidth(), onClick = onSettings)
    }
}

@Composable
fun Chip(name: String, color: Color, active: Boolean, crown: Boolean, modifier: Modifier) {
    val a by animateFloatAsState(if (active) 1f else 0.5f, tween(300), label = "chip")
    val shape = RoundedCornerShape(50)
    Row(modifier.graphicsLayer { alpha = a }.background(color.copy(0.28f), shape)
        .border(if (active) 2.dp else 1.dp, if (active) Gold else fg().copy(0.3f), shape).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Box(Modifier.size(12.dp).background(color, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text((if (crown) "👑 " else "") + name, color = fg(), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GameScreen(g: Game, onExit: () -> Unit) {
    var rolling by remember { mutableStateOf(false) }
    var face by remember { mutableIntStateOf(1) }
    var sent by remember { mutableStateOf(false) }      // blocks double taps until the roll result arrives
    var seen by remember(g) { mutableIntStateOf(g.rollSeq) }
    val spin = remember { Animatable(0f) }

    // One smooth tumble for EVERY roll (yours, bots, opponents on LAN), driven by rollSeq.
    LaunchedEffect(g.rollSeq) {
        sent = false
        if (g.rollSeq != seen) {
            seen = g.rollSeq; rolling = true; Sfx.play("shake")
            spin.snapTo(0f)
            launch { repeat(7) { face = (1..6).random(); delay(95) } }
            spin.animateTo(1f, tween(800, easing = FastOutSlowInEasing))
            spin.snapTo(0f); rolling = false
        }
    }
    LaunchedEffect(g.turn, g.rolled) { sent = false }
    LaunchedEffect(g.turn, g.rolled, g.version) {
        if (g.turn in g.bots && g.winner < 0) { delay(if (g.rolled) 1000 else 900); g.botStep() }
    }
    LaunchedEffect(g.turn) { Sfx.play("turn") }

    val names = stringArrayResource(R.array.player_names)
    val shown = if (g.winner >= 0) g.winner else g.turn
    val nm = g.names[shown] ?: names[shown]
    val mine = g.canAct()
    Column(Modifier.fillMaxSize().padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (p in g.players) Chip(g.names[p] ?: names[p], pColors[p], p == shown, g.winner == p, Modifier.weight(1f))
        }
        BoardView(g, rolling, Modifier.fillMaxWidth().aspectRatio(1f))
        Dice(if (rolling) face else g.dice, pColors[shown], mine && !rolling && !g.rolled && !sent, { spin.value }) {
            sent = true; g.roll()
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(when {
                g.winner >= 0 -> "👑 " + stringResource(R.string.wins, nm)
                mine && g.rolled -> stringResource(R.string.tap_token)
                mine -> stringResource(R.string.tap_dice)
                else -> stringResource(R.string.waiting, nm)
            }, color = fg().copy(0.9f), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (g.mySeat >= 0) StatusDot()
        }
        GlassButton(stringResource(R.string.menu), Modifier.width(160.dp), onClick = onExit)
    }
}

private fun DrawScope.star(cx: Float, cy: Float, r: Float, col: Color) {
    val p = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5; val rr = if (i % 2 == 0) r else r * 0.45f
        val x = cx + (cos(a) * rr).toFloat(); val y = cy + (sin(a) * rr).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close(); drawPath(p, col)
}

private fun DrawScope.quad(a: Offset, b: Offset, c: Offset, d: Offset, col: Color, edge: Color) {
    val p = Path(); p.moveTo(a.x, a.y); p.lineTo(b.x, b.y); p.lineTo(c.x, c.y); p.lineTo(d.x, d.y); p.close()
    drawPath(p, col); drawPath(p, edge, style = Stroke(2.5f))
}

/** 3D cube dice: top + side faces for depth, tumbles with perspective. Tap when it glows. */
@Composable
fun Dice(n: Int, color: Color, active: Boolean, spinP: () -> Float, onClick: () -> Unit) {
    val glow by rememberInfiniteTransition(label = "dg").animateFloat(0.3f, 0.95f,
        infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    Canvas(Modifier.size(132.dp)
        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = active) { onClick() }
        .graphicsLayer {
            val t = spinP()
            rotationX = 720f * t; rotationY = 720f * t; rotationZ = 360f * t
            cameraDistance = 16f * density
            translationY = -abs(sin(t * PI * 3)).toFloat() * 40f * (1f - t) * density
            val s = 1f + 0.18f * sin(t * PI).toFloat(); scaleX = s; scaleY = s
        }) {
        val s = size.minDimension; val d = s * 0.6f; val k = d * 0.17f
        val ox = (s - d - k) / 2f; val oy = ox
        if (active) drawRoundRect(color.copy(alpha = glow * 0.5f), Offset(ox - 14f, oy - 14f), Size(d + k + 28f, d + k + 28f), CornerRadius(d * 0.32f))
        drawOval(Color.Black.copy(0.22f), Offset(ox + k, oy + d + k + 2f), Size(d, k * 1.1f))
        val edge = GoldD
        quad(Offset(ox, oy + k), Offset(ox + k, oy), Offset(ox + d + k, oy), Offset(ox + d, oy + k), Color.White, edge)
        quad(Offset(ox + d, oy + k), Offset(ox + d + k, oy), Offset(ox + d + k, oy + d), Offset(ox + d, oy + d + k), Color(0xFFB9C4DD), edge)
        val fr = CornerRadius(d * 0.1f)
        drawRoundRect(Brush.linearGradient(listOf(Color.White, Color(0xFFDCE3F2)), Offset(ox, oy + k), Offset(ox + d, oy + d + k)), Offset(ox, oy + k), Size(d, d), fr)
        drawRoundRect(edge, Offset(ox, oy + k), Size(d, d), fr, style = Stroke(2.5f))
        val pips = when (n) { 1 -> listOf(4); 2 -> listOf(0, 8); 3 -> listOf(0, 4, 8); 4 -> listOf(0, 2, 6, 8)
            5 -> listOf(0, 2, 4, 6, 8); 6 -> listOf(0, 2, 3, 5, 6, 8); else -> emptyList() }
        for (q in pips) drawCircle(if (n == 1) Color(0xFFD62839) else Color(0xFF1B2140), d * 0.08f,
            Offset(ox + d * (0.27f + 0.23f * (q % 3)), oy + k + d * (0.27f + 0.23f * (q / 3))))
    }
}

private fun posAt(g: Game, p: Int, i: Int, k: Float): Pair<Float, Float> {
    if (k < 0f) return g.pos(p, i)
    val a = floor(k).toInt().coerceIn(0, 56); val b = (a + 1).coerceAtMost(56); val f = k - a
    val c0 = Board.cell(p, a); val c1 = Board.cell(p, b)
    return (c0.first + (c1.first - c0.first) * f + 0.5f) to (c0.second + (c1.second - c0.second) * f + 0.5f)
}

/** Static royal board: velvet field, ivory path, jewel-tone yards, gold frame. Drawn once (no state reads). */
private fun DrawScope.drawBoard() {
    val c = size.width / 15f
    drawRoundRect(Brush.linearGradient(listOf(Color(0xFF232872), Color(0xFF10133A))), cornerRadius = CornerRadius(c * 0.8f))
    for (p in 0..3) {
        val yx = Board.yardX(p) * c; val yy = Board.yardY(p) * c; val col = pColors[p]
        val o = Offset(yx + c * 0.1f, yy + c * 0.1f); val sz = Size(c * 5.8f, c * 5.8f); val rr = CornerRadius(c * 0.7f)
        drawRoundRect(col, o, sz, rr)
        drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(0.3f), Color.Transparent), yy, yy + c * 4f), o, sz, rr)
        drawRoundRect(Ivory, Offset(yx + c * 0.9f, yy + c * 0.9f), Size(c * 4.2f, c * 4.2f), CornerRadius(c * 0.6f))
        drawRoundRect(GoldD, Offset(yx + c * 0.9f, yy + c * 0.9f), Size(c * 4.2f, c * 4.2f), CornerRadius(c * 0.6f), style = Stroke(3f))
        for (i in 0..3) {
            val ctr = Offset(yx + (2f + (i % 2) * 2f) * c, yy + (2f + (i / 2) * 2f) * c)
            drawCircle(col.copy(0.3f), c * 0.52f, ctr); drawCircle(col.copy(0.75f), c * 0.52f, ctr, style = Stroke(2.5f))
        }
    }
    fun cellBox(x: Int, y: Int, col: Color) {
        val o = Offset(x * c + c * 0.05f, y * c + c * 0.05f); val s = Size(c * 0.9f, c * 0.9f)
        drawRoundRect(col, o, s, CornerRadius(c * 0.2f))
        drawRoundRect(GoldD.copy(0.5f), o, s, CornerRadius(c * 0.2f), style = Stroke(1.5f))
    }
    Board.ring.forEachIndexed { i, cell ->
        val sp = Board.start.indexOf(i)
        cellBox(cell.first, cell.second, if (sp >= 0) pColors[sp] else Ivory)
        if (i in Board.safeIdx) star((cell.first + 0.5f) * c, (cell.second + 0.5f) * c, c * 0.3f, if (sp >= 0) Color.White else GoldD)
    }
    for (p in 0..3) for (k in 51..55) Board.cell(p, k).let { cellBox(it.first, it.second, pColors[p].copy(0.95f)) }
    fun tri(a: Offset, b: Offset, col: Color) {
        val p = Path(); p.moveTo(a.x, a.y); p.lineTo(b.x, b.y); p.lineTo(7.5f * c, 7.5f * c); p.close()
        drawPath(p, col); drawPath(p, GoldL, style = Stroke(2.5f))
    }
    tri(Offset(6 * c, 6 * c), Offset(6 * c, 9 * c), pColors[0])
    tri(Offset(6 * c, 6 * c), Offset(9 * c, 6 * c), pColors[1])
    tri(Offset(9 * c, 6 * c), Offset(9 * c, 9 * c), pColors[2])
    tri(Offset(6 * c, 9 * c), Offset(9 * c, 9 * c), pColors[3])
    val mid = Offset(7.5f * c, 7.5f * c)
    drawCircle(Brush.radialGradient(listOf(GoldL, GoldD), mid, c * 0.6f), c * 0.55f, mid)
    star(mid.x, mid.y, c * 0.4f, Color(0xFF7A1E2B))
    drawRoundRect(Brush.linearGradient(listOf(GoldL, GoldD, GoldL, Color(0xFF9A6E1F))), cornerRadius = CornerRadius(c * 0.8f), style = Stroke(c * 0.24f))
}

@Composable
fun BoardView(g: Game, locked: Boolean, modifier: Modifier) {
    // disp = displayed progress; walks toward the real progress one cell at a time.
    val disp = remember(g) { Array(4) { p -> FloatArray(4) { i -> g.prog[p][i].toFloat() } } }
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(g.version) {
        var last = 0L; var moving = true
        while (moving) withFrameNanos { t ->
            val dt = if (last == 0L) 0f else minOf((t - last) / 1e9f, 0.05f)
            last = t; moving = false
            for (p in 0..3) for (i in 0..3) {
                val a = g.prog[p][i].toFloat(); val d = disp[p][i]
                if (a < 0f || d < 0f || d >= a) disp[p][i] = a
                else { disp[p][i] = minOf(a, d + dt * 9f); moving = true }
            }
            frame++
        }
    }
    val pulse by rememberInfiniteTransition(label = "bp").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pp")
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) { drawBoard() }   // cached layer: not redrawn per frame
        Canvas(Modifier.fillMaxSize().pointerInput(g, locked) {
            detectTapGestures { o -> if (!locked) { val c = size.width / 15f; g.tap(o.x / c, o.y / c) } }
        }) {
            frame; g.version
            val c = size.width / 15f
            if (g.winner < 0) { // animated current-player indicator
                val p = g.turn
                drawRoundRect(Gold.copy(alpha = pulse), Offset(Board.yardX(p) * c + c * 0.1f, Board.yardY(p) * c + c * 0.1f),
                    Size(c * 5.8f, c * 5.8f), CornerRadius(c * 0.7f), style = Stroke(c * 0.22f))
            }
            val mv = if (!locked && g.canAct()) g.movable() else emptyList()
            val seen = HashMap<Int, Int>()
            for (p in g.players) for (i in 0..3) {
                val k = disp[p][i]
                val hop = k >= 0f && k < g.prog[p][i]
                val (x, y) = posAt(g, p, i, k)
                val key = if (k >= 0f && !hop) (x * 2).toInt() * 100 + (y * 2).toInt() else -1
                val n = if (key >= 0) (seen[key] ?: 0) else 0
                if (key >= 0) seen[key] = n + 1
                val o = Offset(x * c + n * c * 0.16f, y * c - n * c * 0.16f)   // stacked tokens fan out
                if (hop) {
                    val (tx, ty) = posAt(g, p, i, maxOf(0f, k - 0.7f))
                    drawCircle(pColors[p].copy(0.35f), c * 0.26f, Offset(tx * c, ty * c))
                }
                val r = c * 0.38f * (if (hop) 1f + 0.25f * sin((k - floor(k)) * 3.1416f) else 1f)
                drawCircle(Color.Black.copy(0.35f), r, o + Offset(0f, c * 0.08f))
                drawCircle(Brush.radialGradient(listOf(Color.White, pColors[p], pColors[p].copy(0.85f)), o - Offset(r * 0.3f, r * 0.35f), r * 1.5f), r, o)
                drawCircle(GoldL, r, o, style = Stroke(3f))
                drawCircle(Color.White.copy(0.6f), r * 0.2f, o - Offset(r * 0.35f, r * 0.4f))
                if (p == g.turn && i in mv) drawCircle(Gold, r * 1.4f, o, alpha = pulse, style = Stroke(5f))
            }
        }
    }
}

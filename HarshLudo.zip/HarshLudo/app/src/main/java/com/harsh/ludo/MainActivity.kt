package com.harsh.ludo

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.floor
import kotlin.math.sin

val pColors = listOf(Color(0xFFE5484D), Color(0xFF30A46C), Color(0xFFF5C518), Color(0xFF3E63DD))

@Composable fun fg() = if (Prefs.dark) Color.White else Color(0xFF1B2140)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Prefs.load(this); Sfx.init(this)
        setContent { App() }
    }
    override fun onPause() { super.onPause(); Sfx.pauseMusic() }
    override fun onResume() { super.onResume(); Sfx.applyMusic() }
}

@Composable
fun App() {
    var game by remember { mutableStateOf<Game?>(null) }
    var settings by remember { mutableStateOf(false) }
    BackHandler(enabled = game != null || settings) { game = null; settings = false }
    val bg = if (Prefs.dark) listOf(Color(0xFF1B2A4E), Color(0xFF3B1F5E), Color(0xFF0F5E6B))
    else listOf(Color(0xFFDCE8FF), Color(0xFFF1DCFF), Color(0xFFD5F5F2))
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(bg))) {
        val g = game
        when {
            g != null -> GameScreen(g) { game = null }
            settings -> SettingsScreen()
            else -> Menu(onSettings = { settings = true }) { n, bot ->
                val ps = when (n) { 2 -> listOf(0, 2); 3 -> listOf(0, 1, 2); else -> listOf(0, 1, 2, 3) }
                game = Game(ps, if (bot) ps.drop(1).toSet() else emptySet()).also { it.onEvent = Sfx::play }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Box(modifier.background(Color.White.copy(if (Prefs.dark) 0.14f else 0.55f), shape)
        .border(1.dp, fg().copy(0.35f), shape).padding(16.dp),
        contentAlignment = Alignment.Center, content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Glass(modifier.heightIn(min = 56.dp).clickable(enabled = enabled) { Sfx.play("click"); onClick() }) {
        Text(text, color = fg().copy(if (enabled) 1f else 0.4f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Menu(onSettings: () -> Unit, onStart: (Int, Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("HARSH LUDO", color = fg(), fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
        for (bot in listOf(false, true)) {
            Text(stringResource(if (bot) R.string.vs_bot else R.string.pass_play), color = fg().copy(0.8f), fontSize = 16.sp)
            for (n in 2..4) GlassButton(stringResource(R.string.n_players, n), Modifier.fillMaxWidth()) { onStart(n, bot) }
        }
        GlassButton("⚙ " + stringResource(R.string.settings), Modifier.fillMaxWidth(), onClick = onSettings)
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = fg(), fontSize = 17.sp, modifier = Modifier.weight(1f))
        Switch(v, onChange)
    }
}

@Composable
fun SliderRow(label: String, v: Float, onChange: (Float) -> Unit) {
    Column { Text(label, color = fg(), fontSize = 17.sp); Slider(v, onChange) }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).padding(top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.settings), color = fg(), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Glass(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SwitchRow(stringResource(R.string.sfx), Prefs.sfxOn) { Prefs.sfxOn = it; Prefs.save() }
                SliderRow(stringResource(R.string.sfx_volume), Prefs.sfxVol) { Prefs.sfxVol = it; Prefs.save() }
                SwitchRow(stringResource(R.string.music), Prefs.musicOn) { Prefs.musicOn = it; Prefs.save(); Sfx.applyMusic() }
                SliderRow(stringResource(R.string.music_volume), Prefs.musicVol) { Prefs.musicVol = it; Prefs.save(); Sfx.applyMusic() }
                SwitchRow(stringResource(R.string.vibration), Prefs.vibrate) { Prefs.vibrate = it; Prefs.save() }
                SwitchRow(stringResource(R.string.dark_theme), Prefs.dark) { Prefs.dark = it; Prefs.save() }
                OutlinedTextField(Prefs.name, { Prefs.name = it.take(12); Prefs.save() }, singleLine = true,
                    label = { Text(stringResource(R.string.player_name)) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = fg(), unfocusedTextColor = fg(),
                        focusedLabelColor = fg(), unfocusedLabelColor = fg().copy(0.7f)))
            }
        }
    }
}

@Composable
fun GameScreen(g: Game, onExit: () -> Unit) {
    var rolling by remember { mutableStateOf(false) }
    var face by remember { mutableIntStateOf(1) }
    val scope = rememberCoroutineScope()
    // Dice tumble: random faces for ~0.6s, buttons stay disabled meanwhile (prevents double rolls).
    suspend fun spin() { rolling = true; Sfx.play("shake"); repeat(9) { face = (1..6).random(); delay(70) }; rolling = false }

    LaunchedEffect(g.turn, g.rolled, g.version) {
        if (g.turn in g.bots && g.winner < 0) { delay(600); if (!g.rolled) spin(); g.botStep() }
    }
    LaunchedEffect(g.turn) { Sfx.play("turn") }
    val names = stringArrayResource(R.array.player_names)
    val shown = if (g.winner >= 0) g.winner else g.turn
    val humanTurn = g.turn !in g.bots
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Glass(Modifier.fillMaxWidth().padding(top = 24.dp)) {
            Text(if (g.winner >= 0) stringResource(R.string.wins, names[shown]) else stringResource(R.string.turn, names[shown]),
                color = pColors[shown], fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        BoardView(g, Modifier.fillMaxWidth().aspectRatio(1f))
        val n = if (rolling) face else g.dice
        Glass(Modifier.size(96.dp).graphicsLayer { rotationZ = if (rolling) face * 57f else 0f }) {
            Text(if (n == 0) "-" else "$n", color = fg(), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
        }
        if (g.rolled && humanTurn) Text(stringResource(R.string.tap_token), color = fg().copy(0.8f), fontSize = 16.sp)
        GlassButton(stringResource(R.string.roll), Modifier.fillMaxWidth(),
            enabled = !rolling && !g.rolled && humanTurn && g.winner < 0) { scope.launch { spin(); g.roll() } }
        GlassButton(stringResource(R.string.menu), Modifier.fillMaxWidth(), onClick = onExit)
    }
}

private fun posAt(g: Game, p: Int, i: Int, k: Float): Pair<Float, Float> {
    if (k < 0f) return g.pos(p, i)
    val a = floor(k).toInt().coerceIn(0, 56); val b = (a + 1).coerceAtMost(56); val f = k - a
    val c0 = Board.cell(p, a); val c1 = Board.cell(p, b)
    return (c0.first + (c1.first - c0.first) * f + 0.5f) to (c0.second + (c1.second - c0.second) * f + 0.5f)
}

@Composable
fun BoardView(g: Game, modifier: Modifier) {
    val fg = fg()
    // disp = displayed progress; walks toward the real progress one cell at a time (10 cells/s).
    val disp = remember(g) { Array(4) { p -> FloatArray(4) { i -> g.prog[p][i].toFloat() } } }
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(g.version) {
        var last = 0L; var moving = true
        while (moving) withFrameNanos { t ->
            val dt = if (last == 0L) 0f else (t - last) / 1e9f
            last = t; moving = false
            for (p in 0..3) for (i in 0..3) {
                val a = g.prog[p][i].toFloat(); val d = disp[p][i]
                if (a < 0f || d < 0f || d >= a) disp[p][i] = a
                else { disp[p][i] = minOf(a, d + dt * 10f); moving = true }
            }
            frame++
        }
    }
    Canvas(modifier.pointerInput(g) { detectTapGestures { o -> val c = size.width / 15f; g.tap(o.x / c, o.y / c) } }) {
        frame; g.version
        val c = size.width / 15f
        drawRoundRect(fg.copy(0.08f), cornerRadius = CornerRadius(c))
        drawRoundRect(fg.copy(0.35f), cornerRadius = CornerRadius(c), style = Stroke(2f))
        for (p in 0..3) drawRoundRect(pColors[p].copy(0.30f), Offset(Board.yardX(p) * c, Board.yardY(p) * c), Size(6 * c, 6 * c), CornerRadius(c * 0.6f))
        fun cellBox(x: Int, y: Int, col: Color) =
            drawRoundRect(col, Offset(x * c + c * 0.06f, y * c + c * 0.06f), Size(c * 0.88f, c * 0.88f), CornerRadius(c * 0.2f))
        Board.ring.forEachIndexed { i, cell ->
            val sp = Board.start.indexOf(i)
            cellBox(cell.first, cell.second, if (sp >= 0) pColors[sp].copy(0.8f) else fg.copy(0.15f))
            if (i in Board.safeIdx) drawCircle(fg.copy(0.9f), c * 0.22f, Offset((cell.first + 0.5f) * c, (cell.second + 0.5f) * c), style = Stroke(3f))
        }
        for (p in 0..3) for (k in 51..55) Board.cell(p, k).let { cellBox(it.first, it.second, pColors[p].copy(0.55f)) }
        drawCircle(fg.copy(0.2f), c * 1.1f, Offset(7.5f * c, 7.5f * c))
        val mv = if (g.turn !in g.bots) g.movable() else emptyList()
        for (p in g.players) for (i in 0..3) {
            val k = disp[p][i]
            val hop = k >= 0f && k < g.prog[p][i]
            val (x, y) = posAt(g, p, i, k)
            val o = Offset(x * c, y * c)
            if (hop) { // glow trail behind the moving token
                val (tx, ty) = posAt(g, p, i, maxOf(0f, k - 0.7f))
                drawCircle(pColors[p].copy(0.3f), c * 0.24f, Offset(tx * c, ty * c))
            }
            val r = c * 0.33f * (if (hop) 1f + 0.25f * sin((k - floor(k)) * 3.1416f) else 1f)
            drawCircle(Color.Black.copy(0.3f), r, o + Offset(0f, c * 0.05f))
            drawCircle(pColors[p], r, o)
            drawCircle(fg, r, o, style = Stroke(3f))
            if (p == g.turn && i in mv) drawCircle(fg, c * 0.45f, o, style = Stroke(5f))
        }
    }
}

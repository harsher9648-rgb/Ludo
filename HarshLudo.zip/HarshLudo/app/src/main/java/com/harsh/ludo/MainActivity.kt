package com.harsh.ludo

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.minDimension
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

// Royal palette: jewel-tone players + gold accents.
val pColors = listOf(Color(0xFFD62839), Color(0xFF1FA463), Color(0xFFF2B01E), Color(0xFF2B63D9))
val Gold = Color(0xFFE8C468)
val GoldL = Color(0xFFF7E29A)
val GoldD = Color(0xFFB8862B)
private val Ivory = Color(0xFFF6EFD9)

@Composable fun fg() = if (Prefs.dark) Color(0xFFF5EEDC) else Color(0xFF241A4A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Prefs.load(this); Sfx.init(this)
        setContent { App() }
    }
    override fun onPause() { super.onPause(); Sfx.pauseMusic() }
    override fun onResume() { super.onResume(); Sfx.applyMusic() }
}

@Composable
fun App() {
    var game by remember { mutableStateOf<Game?>(null) }
    var settings by remember { mutableStateOf(false) }
    var lan by remember { mutableStateOf(false) }
    val back: () -> Unit = {
        when {
            Lan.game != null -> Lan.exitGame()
            lan -> { Lan.stop(); lan = false }
            else -> { game = null; settings = false }
        }
    }
    BackHandler(enabled = game != null || settings || lan || Lan.game != null) { back() }
    val dark = Prefs.dark
    val bg = if (dark) listOf(Color(0xFF0B0F2E), Color(0xFF231046), Color(0xFF3B1236))
    else listOf(Color(0xFFFFF7E3), Color(0xFFF6E7C4), Color(0xFFEBD6A4))
    // Liquid light blobs: pre-rendered layers moved on the GPU (no per-frame redraw = no lag).
    val drift by rememberInfiniteTransition(label = "bg").animateFloat(-1f, 1f,
        infiniteRepeatable(tween(12000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "d")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(bg))) {
        Box(Modifier.size(360.dp).align(Alignment.TopStart)
            .graphicsLayer { translationX = drift * 90f; translationY = drift * 50f }
            .background(Brush.radialGradient(listOf(Gold.copy(if (dark) 0.20f else 0.40f), Color.Transparent)), CircleShape))
        Box(Modifier.size(320.dp).align(Alignment.BottomEnd)
            .graphicsLayer { translationX = -drift * 80f; translationY = -drift * 60f }
            .background(Brush.radialGradient(listOf(Color(0xFF7C4DFF).copy(if (dark) 0.28f else 0.16f), Color.Transparent)), CircleShape))
        val key = when { Lan.game != null -> 4; game != null -> 3; settings -> 1; lan -> 2; else -> 0 }
        AnimatedContent(key, transitionSpec = {
            (fadeIn(tween(280)) + scaleIn(tween(280), initialScale = 0.96f)) togetherWith fadeOut(tween(160))
        }, label = "screen") { k ->
            when (k) {
                4 -> Lan.game?.let { GameScreen(it) { Lan.exitGame() } }
                3 -> game?.let { GameScreen(it) { game = null } }
                1 -> SettingsScreen()
                2 -> LanScreen()
                else -> Menu(onSettings = { settings = true }, onLan = { lan = true }) { n, bot ->
                    val ps = when (n) { 2 -> listOf(0, 2); 3 -> listOf(0, 1, 2); else -> listOf(0, 1, 2, 3) }
                    game = Game(ps, if (bot) ps.drop(1).toSet() else emptySet()).also { it.onEvent = { e -> Sfx.play(e) } }
                }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, pad: Dp = 16.dp, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val d = Prefs.dark
    Box(modifier
        .background(Brush.verticalGradient(listOf(Color.White.copy(if (d) 0.20f else 0.80f), Color.White.copy(if (d) 0.06f else 0.45f))), shape)
        .border(1.2.dp, Brush.verticalGradient(listOf(Gold.copy(0.85f), Gold.copy(0.15f))), shape)
        .padding(pad), contentAlignment = Alignment.Center, content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.93f else 1f, spring(0.5f, Spring.StiffnessMediumLow), label = "btn")
    Glass(modifier.heightIn(min = 56.dp).graphicsLayer { scaleX = sc; scaleY = sc }
        .clickable(interactionSource = src, indication = null, enabled = enabled) { Sfx.play("click"); onClick() }) {
        Text(text, color = fg().copy(if (enabled) 1f else 0.4f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

/** Ludo-King style logo: crown + two pin pawns flanking a colorful "HARSH LUDO" wordmark. */
@Composable
fun Logo() {
    val letterColors = listOf(Color(0xFFE5484D), Color(0xFF2ECC71), Color(0xFFF2B01E), Color(0xFF2B63D9),
        Color(0xFFE5484D), Color(0xFF7C4DFF), Color(0xFF2ECC71), Color(0xFFF2B01E), Color(0xFF2B63D9))
    Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Canvas(Modifier.size(34.dp, 46.dp)) { drawPin(Offset(size.width * 0.55f, size.height * 0.92f), size.width * 0.46f, Color(0xFF2B63D9)) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("👑", fontSize = 30.sp)
                Row {
                    "HARSH LUDO".forEachIndexed { i, ch ->
                        if (ch == ' ') Spacer(Modifier.width(8.dp))
                        else Text(ch.toString(), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                            style = TextStyle(color = letterColors[i % letterColors.size],
                                shadow = Shadow(Color.Black.copy(0.5f), Offset(1.5f, 2.5f), 1f)))
                    }
                }
            }
            Canvas(Modifier.size(34.dp, 46.dp)) { drawPin(Offset(size.width * 0.45f, size.height * 0.92f), size.width * 0.46f, Color(0xFF2ECC71)) }
        }
    }
}

private fun lighten(c: Color, f: Float) = Color(c.red + (1 - c.red) * f, c.green + (1 - c.green) * f, c.blue + (1 - c.blue) * f, c.alpha)
private fun darken(c: Color, f: Float) = Color(c.red * (1 - f), c.green * (1 - f), c.blue * (1 - f), c.alpha)

/** Glossy 3D King-style button: bevel highlight, deep base color, gold rim, icon chip + label plate. */
@Composable
fun KingButton(icon: String, label: String, base: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else 1f, spring(0.5f, Spring.StiffnessMediumLow), label = "kb")
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.aspectRatio(1.15f).graphicsLayer { scaleX = sc; scaleY = sc }
        .shadow(8.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
        .background(Brush.verticalGradient(listOf(lighten(base, 0.35f), base, darken(base, 0.25f))), shape)
        .border(2.5.dp, Brush.verticalGradient(listOf(GoldL, GoldD)), shape)
        .clickable(interactionSource = src, indication = null, onClick = { Sfx.play("click"); onClick() })
        .padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.weight(1f).fillMaxWidth().padding(4.dp)
            .background(Brush.radialGradient(listOf(Color.White, Color.White.copy(0.7f)), radius = 90f), CircleShape)
            .border(1.5.dp, base.copy(0.5f), CircleShape), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 30.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().background(Color.Black.copy(0.28f), RoundedCornerShape(8.dp)).padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                style = TextStyle(shadow = Shadow(Color.Black, Offset(1f, 1f), 2f)))
        }
    }
}

@Composable
fun Menu(onSettings: () -> Unit, onLan: () -> Unit, onStart: (Int, Boolean) -> Unit) {
    var pick by remember { mutableStateOf(0) }   // 0 = grid, 1 = pass&play count, 2 = vs bot count
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
        Logo()
        AnimatedContent(pick, transitionSpec = { (fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.95f)) togetherWith fadeOut(tween(140)) }, label = "menu") { p ->
            when (p) {
                0 -> Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        KingButton("🌐", stringResource(R.string.offline_lan), Color(0xFF2B63D9), Modifier.weight(1f), onLan)
                        KingButton("🤖", stringResource(R.string.vs_bot), Color(0xFFD62839), Modifier.weight(1f)) { pick = 2 }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        KingButton("👥", stringResource(R.string.pass_play), Color(0xFF1FA463), Modifier.weight(1f)) { pick = 1 }
                        KingButton("⚙", stringResource(R.string.settings), Color(0xFFF2B01E), Modifier.weight(1f), onSettings)
                    }
                }
                else -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(if (p == 2) R.string.vs_bot else R.string.pass_play), color = fg(), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    for (n in 2..4) GlassButton(stringResource(R.string.n_players, n), Modifier.fillMaxWidth()) { onStart(n, p == 2) }
                    GlassButton("◀", Modifier.width(70.dp)) { pick = 0 }
                }
            }
        }
    }
}

@Composable
fun Slot(p: Int, left: Boolean, n: Int, active: Boolean, canRoll: Boolean, spinP: () -> Float, onRoll: () -> Unit) {
    val bob by rememberInfiniteTransition(label = "arrow").animateFloat(0f, 8f,
        infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val shape = RoundedCornerShape(14.dp)
    val a by animateFloatAsState(if (active || n >= 0) 1f else 0.6f, tween(250), label = "slot")
    val arrow: @Composable () -> Unit = {
        Box(Modifier.width(22.dp), contentAlignment = Alignment.Center) {
            if (canRoll) Text(if (left) "◀" else "▶", color = Color(0xFFFF9F1C), fontSize = 20.sp,
                modifier = Modifier.graphicsLayer { translationX = (if (left) -bob else bob) * density })
        }
    }
    val pin: @Composable () -> Unit = {
        Canvas(Modifier.size(26.dp)) { drawPin(Offset(size.width / 2f, size.height * 0.95f), size.width * 0.5f, pColors[p]) }
    }
    Row(Modifier.graphicsLayer { alpha = a }.background(Color(0xFF15359B), shape)
        .border(2.dp, if (active) GoldL else Gold.copy(0.6f), shape).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (!left) arrow()
        if (left) pin()
        Box(Modifier.size(72.dp).background(Brush.verticalGradient(listOf(Color.White, Color(0xFFE9C6C6))), RoundedCornerShape(12.dp))
            .border(2.dp, Color(0xFF7D7D7D), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Dice(n, pColors[p], canRoll, 72.dp, spinP, onRoll)
        }
        if (!left) pin()
        if (left) arrow()
    }
}

@Composable
fun SlotFor(g: Game, p: Int, left: Boolean, rolling: Boolean, face: Int, spin: Animatable<Float, AnimationVector1D>,
            canRoll: Boolean, onRoll: () -> Unit) {
    if (p !in g.players) { Spacer(Modifier.width(1.dp)); return }
    val active = g.winner < 0 && p == g.turn
    val roller = p == g.rollBy && g.rollSeq > 0
    // Dice shows in the roller's slot (every phone), blank glowing die in the slot whose turn it is.
    val n = when { roller && rolling -> face; active && g.rolled -> g.dice; active -> 0; roller -> g.dice; else -> -1 }
    Slot(p, left, n, active, active && canRoll, { if (roller && rolling) spin.value else 0f }, onRoll)
}

@Composable
fun GameScreen(g: Game, onExit: () -> Unit) {
    var rolling by remember { mutableStateOf(false) }
    var face by remember { mutableIntStateOf(1) }
    var sent by remember { mutableStateOf(false) }      // blocks double taps until the roll result arrives
    var seen by remember(g) { mutableIntStateOf(g.rollSeq) }
    val spin = remember { Animatable(0f) }

    // One smooth tumble for EVERY roll (yours, bots, opponents on LAN), driven by rollSeq.
    LaunchedEffect(g.rollSeq) {
        sent = false
        if (g.rollSeq != seen) {
            seen = g.rollSeq; rolling = true; Sfx.play("shake")
            spin.snapTo(0f)
            launch { repeat(5) { face = (1..6).random(); delay(70) } }
            spin.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
            spin.snapTo(0f); rolling = false
        }
    }
    LaunchedEffect(g.turn, g.rolled) { sent = false }
    LaunchedEffect(g.turn, g.rolled, g.version) {
        if (g.turn in g.bots && g.winner < 0) { delay(if (g.rolled) 1000 else 900); g.botStep() }
    }
    LaunchedEffect(g.turn) { Sfx.play("turn") }

    val names = stringArrayResource(R.array.player_names)
    val you = stringResource(R.string.you)
    val labels = HashMap<Int, String>()
    for (p in g.players) labels[p] = g.names[p] ?: if (g.bots.isNotEmpty()) { if (p == 0) you else stringResource(R.string.computer, p + 1) } else names[p]
    val shown = if (g.winner >= 0) g.winner else g.turn
    val nm = labels[shown] ?: ""
    val mine = g.canAct()
    val canRoll = mine && !rolling && !g.rolled && !sent
    val onRoll = { sent = true; g.roll() }
    Column(Modifier.fillMaxSize().padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            SlotFor(g, 1, true, rolling, face, spin, canRoll, onRoll)
            SlotFor(g, 2, false, rolling, face, spin, canRoll, onRoll)
        }
        BoardView(g, rolling, labels, Modifier.fillMaxWidth().aspectRatio(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SlotFor(g, 0, true, rolling, face, spin, canRoll, onRoll)
            GlassButton("☰", Modifier.width(60.dp), onClick = onExit)
            SlotFor(g, 3, false, rolling, face, spin, canRoll, onRoll)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(when {
                g.winner >= 0 -> "👑 " + stringResource(R.string.wins, nm)
                mine && g.rolled -> stringResource(R.string.tap_token)
                mine -> stringResource(R.string.tap_dice)
                else -> stringResource(R.string.waiting, nm)
            }, color = fg().copy(0.9f), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (g.mySeat >= 0) StatusDot()
        }
    }
}

/** Map-pin token: white body, colored head. `o` is the point on the ground (pin tip). */
private fun DrawScope.drawPin(o: Offset, r: Float, col: Color) {
    val hr = r * 0.78f; val hc = Offset(o.x, o.y - r)
    val body = Path().apply {
        addOval(Rect(hc.x - hr, hc.y - hr, hc.x + hr, hc.y + hr))
        moveTo(hc.x - hr * 0.8f, hc.y + hr * 0.6f); lineTo(o.x, o.y); lineTo(hc.x + hr * 0.8f, hc.y + hr * 0.6f); close()
    }
    drawPath(body, Color.Black.copy(0.5f), style = Stroke(r * 0.28f))
    drawPath(body, Color.White)
    drawCircle(Brush.radialGradient(listOf(Color.White, col, col.copy(0.85f)), hc - Offset(hr * 0.25f, hr * 0.3f), hr * 1.2f), hr * 0.62f, hc)
}

private fun DrawScope.star(cx: Float, cy: Float, r: Float, col: Color) {
    val p = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5; val rr = if (i % 2 == 0) r else r * 0.45f
        val x = cx + (cos(a) * rr).toFloat(); val y = cy + (sin(a) * rr).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close(); drawPath(p, col)
}

private fun DrawScope.quad(a: Offset, b: Offset, c: Offset, d: Offset, col: Color, edge: Color) {
    val p = Path(); p.moveTo(a.x, a.y); p.lineTo(b.x, b.y); p.lineTo(c.x, c.y); p.lineTo(d.x, d.y); p.close()
    drawPath(p, col); drawPath(p, edge, style = Stroke(2.5f))
}

/** Dice with depth (top + side faces). Tumbles with perspective; blank + glowing = "tap me". n < 0 hides it. */
@Composable
fun Dice(n: Int, color: Color, active: Boolean, size: Dp, spinP: () -> Float, onClick: () -> Unit) {
    val glow by rememberInfiniteTransition(label = "dg").animateFloat(0.3f, 0.95f,
        infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    if (n < 0) { Spacer(Modifier.size(size)); return }
    Canvas(Modifier.size(size)
        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = active) { onClick() }
        .graphicsLayer {
            val t = spinP()
            rotationX = 720f * t; rotationY = 720f * t; rotationZ = 360f * t
            cameraDistance = 16f * density
            translationY = -abs(sin(t * PI * 3)).toFloat() * 24f * (1f - t) * density
            val s = 1f + 0.18f * sin(t * PI).toFloat(); scaleX = s; scaleY = s
        }) {
        val s = size.minDimension; val d = s * 0.72f; val k = d * 0.13f
        val ox = (s - d - k) / 2f; val oy = ox
        if (active) drawRoundRect(color.copy(alpha = glow * 0.55f), Offset(ox - 6f, oy - 6f), Size(d + k + 12f, d + k + 12f), CornerRadius(d * 0.3f))
        drawOval(Color.Black.copy(0.2f), Offset(ox + k, oy + d + k), Size(d, k))
        val edge = Color(0xFF8A8A8A)
        quad(Offset(ox, oy + k), Offset(ox + k, oy), Offset(ox + d + k, oy), Offset(ox + d, oy + k), Color.White, edge)
        quad(Offset(ox + d, oy + k), Offset(ox + d + k, oy), Offset(ox + d + k, oy + d), Offset(ox + d, oy + d + k), Color(0xFFB9C4DD), edge)
        val fr = CornerRadius(d * 0.16f)
        drawRoundRect(Brush.linearGradient(listOf(Color.White, Color(0xFFE2E7F3)), Offset(ox, oy + k), Offset(ox + d, oy + d + k)), Offset(ox, oy + k), Size(d, d), fr)
        drawRoundRect(edge, Offset(ox, oy + k), Size(d, d), fr, style = Stroke(2.5f))
        val pips = when (n) { 1 -> listOf(4); 2 -> listOf(0, 8); 3 -> listOf(0, 4, 8); 4 -> listOf(0, 2, 6, 8)
            5 -> listOf(0, 2, 4, 6, 8); 6 -> listOf(0, 2, 3, 5, 6, 8); else -> emptyList() }
        for (q in pips) drawCircle(if (n == 1) Color(0xFFD62839) else Color(0xFF1B2140), d * 0.08f,
            Offset(ox + d * (0.27f + 0.23f * (q % 3)), oy + k + d * (0.27f + 0.23f * (q / 3))))
    }
}

private fun posAt(g: Game, p: Int, i: Int, k: Float): Pair<Float, Float> {
    if (k < 0f) return g.pos(p, i)
    val a = floor(k).toInt().coerceIn(0, 56); val b = (a + 1).coerceAtMost(56); val f = k - a
    val c0 = Board.cell(p, a); val c1 = Board.cell(p, b)
    return (c0.first + (c1.first - c0.first) * f + 0.5f) to (c0.second + (c1.second - c0.second) * f + 0.5f)
}

/** Static board (classic bright layout, gold frame). Drawn once: no state reads, so no per-frame cost. */
private fun DrawScope.drawBoard() {
    val c = size.width / 15f
    drawRoundRect(Color.White, cornerRadius = CornerRadius(c * 0.8f))
    for (p in 0..3) {
        val yx = Board.yardX(p) * c; val yy = Board.yardY(p) * c; val col = pColors[p]
        val o = Offset(yx + c * 0.1f, yy + c * 0.1f); val sz = Size(c * 5.8f, c * 5.8f); val rr = CornerRadius(c * 0.7f)
        drawRoundRect(col, o, sz, rr)
        drawRoundRect(Brush.verticalGradient(listOf(Color.White.copy(0.25f), Color.Transparent), yy, yy + c * 4f), o, sz, rr)
        drawRoundRect(Color.White, Offset(yx + c * 0.9f, yy + c * 0.9f), Size(c * 4.2f, c * 4.2f), CornerRadius(c * 0.5f))
        for (i in 0..3) drawCircle(col, c * 0.52f, Offset(yx + (2f + (i % 2) * 2f) * c, yy + (2f + (i / 2) * 2f) * c))
    }
    fun cellBox(x: Int, y: Int, col: Color) {
        val o = Offset(x * c + c * 0.03f, y * c + c * 0.03f); val s = Size(c * 0.94f, c * 0.94f)
        drawRoundRect(col, o, s, CornerRadius(c * 0.12f))
        drawRoundRect(Color.Black.copy(0.22f), o, s, CornerRadius(c * 0.12f), style = Stroke(1.4f))
    }
    Board.ring.forEachIndexed { i, cell ->
        val sp = Board.start.indexOf(i)
        cellBox(cell.first, cell.second, if (sp >= 0) pColors[sp] else Color.White)
        if (i in Board.safeIdx) star((cell.first + 0.5f) * c, (cell.second + 0.5f) * c, c * 0.32f, if (sp >= 0) Color.White else Color(0xFF8A8A8A))
    }
    for (p in 0..3) for (k in 51..55) Board.cell(p, k).let { cellBox(it.first, it.second, pColors[p]) }
    fun tri(a: Offset, b: Offset, col: Color) {
        val p = Path(); p.moveTo(a.x, a.y); p.lineTo(b.x, b.y); p.lineTo(7.5f * c, 7.5f * c); p.close()
        drawPath(p, col); drawPath(p, Color.White.copy(0.8f), style = Stroke(2f))
    }
    tri(Offset(6 * c, 6 * c), Offset(6 * c, 9 * c), pColors[1])   // green: left
    tri(Offset(6 * c, 6 * c), Offset(9 * c, 6 * c), pColors[2])   // yellow: top
    tri(Offset(9 * c, 6 * c), Offset(9 * c, 9 * c), pColors[3])   // blue: right
    tri(Offset(6 * c, 9 * c), Offset(9 * c, 9 * c), pColors[0])   // red: bottom
    drawRoundRect(Brush.linearGradient(listOf(GoldL, GoldD, GoldL, Color(0xFF9A6E1F))), cornerRadius = CornerRadius(c * 0.8f), style = Stroke(c * 0.24f))
}

@Composable
fun BoardView(g: Game, locked: Boolean, labels: Map<Int, String>, modifier: Modifier) {
    // disp = displayed progress; walks toward the real progress one cell at a time (hop per step).
    val disp = remember(g) { Array(4) { p -> FloatArray(4) { i -> g.prog[p][i].toFloat() } } }
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(g.version) {
        var last = 0L; var moving = true
        while (moving) withFrameNanos { t ->
            val dt = if (last == 0L) 0f else minOf((t - last) / 1e9f, 0.05f)
            last = t; moving = false
            for (p in 0..3) for (i in 0..3) {
                val a = g.prog[p][i].toFloat(); val d = disp[p][i]
                if (a < 0f || d < 0f || d >= a) disp[p][i] = a
                else { disp[p][i] = minOf(a, d + dt * 13f); moving = true }
            }
            frame++
        }
    }
    val pulse by rememberInfiniteTransition(label = "bp").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pp")
    val crown by animateFloatAsState(if (g.winner >= 0) 1f else 0f, spring(0.45f, Spring.StiffnessLow), label = "crown")

    BoxWithConstraints(modifier) {
        val cd = maxWidth / 15f
        Canvas(Modifier.fillMaxSize()) { drawBoard() }   // cached layer
        Canvas(Modifier.fillMaxSize().pointerInput(g, locked) {
            detectTapGestures { o -> if (!locked) { val c = size.width / 15f; g.tap(o.x / c, o.y / c) } }
        }) {
            frame; g.version
            val c = size.width / 15f
            if (g.winner < 0) { // active player's yard band darkens/pulses, like the reference
                val p = g.turn
                drawRoundRect(Color.Black.copy(alpha = 0.06f + 0.18f * pulse), Offset(Board.yardX(p) * c + c * 0.5f, Board.yardY(p) * c + c * 0.5f),
                    Size(c * 5f, c * 5f), CornerRadius(c * 0.4f), style = Stroke(c * 0.8f))
            }
            val mv = if (!locked && g.canAct()) g.movable() else emptyList()
            val seen = HashMap<Int, Int>()
            for (p in g.players) for (i in 0..3) {
                val k = disp[p][i]; val act = g.prog[p][i]
                val hop = k >= 0f && k < act
                val (x, y) = posAt(g, p, i, k)
                val key = if (k >= 0f && !hop) (x * 2).toInt() * 100 + (y * 2).toInt() else -1
                val n = if (key >= 0) (seen[key] ?: 0) else 0
                if (key >= 0) seen[key] = n + 1
                val gx = x * c + n * c * 0.16f; val gy = y * c + c * 0.30f - n * c * 0.16f   // ground point (pin tip)
                val movable = p == g.turn && i in mv
                val sc = (if (act == 56 && !hop) 0.7f else 1f) * (if (hop) 1f + 0.08f * sin((k - floor(k)) * 3.1416f) else 1f) *
                    (if (movable) 1f + (pulse - 0.3f) * 0.12f else 1f)   // gentle squash on the move, soft breathe when selectable
                if (hop) for (trail in 1..2) {   // short glow tail = glide feel, no per-cell up/down hop
                    val (tx, ty) = posAt(g, p, i, maxOf(0f, k - trail * 0.55f))
                    drawCircle(pColors[p].copy(0.28f / trail), c * 0.24f * sc, Offset(tx * c, ty * c + c * 0.1f))
                }
                drawOval(if (movable) Gold else Color.Black.copy(0.4f), Offset(gx - c * 0.3f * sc, gy - c * 0.09f), Size(c * 0.6f * sc, c * 0.2f), style = Stroke(2.5f))
                drawPin(Offset(gx, gy), c * 0.36f * sc, pColors[p])
            }
        }
        for (p in g.players) Text(labels[p] ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = TextStyle(color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                shadow = Shadow(Color.Black, Offset(1f, 1f), 3f)),
            modifier = Modifier.offset(cd * Board.yardX(p), cd * (Board.yardY(p) + (if (Board.yardY(p) == 0) 0.12f else 5.12f))).width(cd * 6f))
        if (g.winner >= 0) { // rank-1 crown pops over the winner's yard
            val w = g.winner
            Box(Modifier.offset(cd * Board.yardX(w), cd * Board.yardY(w)).size(cd * 6f)
                .graphicsLayer { scaleX = crown; scaleY = crown }, contentAlignment = Alignment.Center) {
                Text("👑", fontSize = (cd.value * 3.2f).sp)
                Text("1", color = Color.Black, fontSize = (cd.value * 1.6f).sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.offset(y = cd * 0.5f))
            }
        }
    }
}

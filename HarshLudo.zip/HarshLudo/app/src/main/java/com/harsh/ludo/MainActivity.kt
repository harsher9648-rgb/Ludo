package com.harsh.ludo

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val pColors = listOf(Color(0xFFE5484D), Color(0xFF30A46C), Color(0xFFF5C518), Color(0xFF3E63DD))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { App() }
    }
}

@Composable
fun App() {
    var game by remember { mutableStateOf<Game?>(null) }
    BackHandler(enabled = game != null) { game = null }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B2A4E), Color(0xFF3B1F5E), Color(0xFF0F5E6B))))) {
        val g = game
        if (g == null) Menu { n, bot ->
            val ps = when (n) { 2 -> listOf(0, 2); 3 -> listOf(0, 1, 2); else -> listOf(0, 1, 2, 3) }
            game = Game(ps, if (bot) ps.drop(1).toSet() else emptySet())
        } else GameScreen(g) { game = null }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.background(Color.White.copy(0.14f), RoundedCornerShape(24.dp))
        .border(1.dp, Color.White.copy(0.4f), RoundedCornerShape(24.dp)).padding(16.dp),
        contentAlignment = Alignment.Center, content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Glass(modifier.heightIn(min = 56.dp).clickable(enabled = enabled, onClick = onClick)) {
        Text(text, color = Color.White.copy(if (enabled) 1f else 0.4f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Menu(onStart: (Int, Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("HARSH LUDO", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
        for (bot in listOf(false, true)) {
            Text(stringResource(if (bot) R.string.vs_bot else R.string.pass_play), color = Color.White.copy(0.8f), fontSize = 16.sp)
            for (n in 2..4) GlassButton(stringResource(R.string.n_players, n), Modifier.fillMaxWidth()) { onStart(n, bot) }
        }
    }
}

@Composable
fun GameScreen(g: Game, onExit: () -> Unit) {
    LaunchedEffect(g.turn, g.rolled, g.version) {
        if (g.turn in g.bots && g.winner < 0) { delay(800); g.botStep() }
    }
    val names = stringArrayResource(R.array.player_names)
    val shown = if (g.winner >= 0) g.winner else g.turn
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Glass(Modifier.fillMaxWidth().padding(top = 24.dp)) {
            Text(if (g.winner >= 0) stringResource(R.string.wins, names[shown]) else stringResource(R.string.turn, names[shown]),
                color = pColors[shown], fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        BoardView(g, Modifier.fillMaxWidth().aspectRatio(1f))
        Text("🎲 ${if (g.dice == 0) "-" else g.dice}", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        if (g.rolled && g.turn !in g.bots) Text(stringResource(R.string.tap_token), color = Color.White.copy(0.8f), fontSize = 16.sp)
        GlassButton(stringResource(R.string.roll), Modifier.fillMaxWidth(),
            enabled = !g.rolled && g.turn !in g.bots && g.winner < 0) { g.roll() }
        GlassButton(stringResource(R.string.menu), Modifier.fillMaxWidth(), onClick = onExit)
    }
}

@Composable
fun BoardView(g: Game, modifier: Modifier) {
    Canvas(modifier.pointerInput(g) { detectTapGestures { o -> val c = size.width / 15f; g.tap(o.x / c, o.y / c) } }) {
        g.version
        val c = size.width / 15f
        drawRoundRect(Color.White.copy(0.10f), cornerRadius = CornerRadius(c))
        drawRoundRect(Color.White.copy(0.35f), cornerRadius = CornerRadius(c), style = Stroke(2f))
        for (p in 0..3) drawRoundRect(pColors[p].copy(0.30f), Offset(Board.yardX(p) * c, Board.yardY(p) * c), Size(6 * c, 6 * c), CornerRadius(c * 0.6f))
        fun cellBox(x: Int, y: Int, col: Color) =
            drawRoundRect(col, Offset(x * c + c * 0.06f, y * c + c * 0.06f), Size(c * 0.88f, c * 0.88f), CornerRadius(c * 0.2f))
        Board.ring.forEachIndexed { i, cell ->
            val sp = Board.start.indexOf(i)
            cellBox(cell.first, cell.second, if (sp >= 0) pColors[sp].copy(0.8f) else Color.White.copy(0.22f))
            if (i in Board.safeIdx) drawCircle(Color.White.copy(0.9f), c * 0.22f, Offset((cell.first + 0.5f) * c, (cell.second + 0.5f) * c), style = Stroke(3f))
        }
        for (p in 0..3) for (k in 51..55) Board.cell(p, k).let { cellBox(it.first, it.second, pColors[p].copy(0.55f)) }
        drawCircle(Color.White.copy(0.25f), c * 1.1f, Offset(7.5f * c, 7.5f * c))
        val mv = if (g.turn !in g.bots) g.movable() else emptyList()
        for (p in g.players) for (i in 0..3) {
            val (x, y) = g.pos(p, i)
            val o = Offset(x * c, y * c)
            drawCircle(Color.Black.copy(0.3f), c * 0.36f, o + Offset(0f, c * 0.05f))
            drawCircle(pColors[p], c * 0.33f, o)
            drawCircle(Color.White, c * 0.33f, o, style = Stroke(3f))
            if (p == g.turn && i in mv) drawCircle(Color.White, c * 0.45f, o, style = Stroke(5f))
        }
    }
}
